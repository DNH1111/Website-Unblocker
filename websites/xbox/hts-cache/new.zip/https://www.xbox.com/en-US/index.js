<!DOCTYPE html>
<html lang="en">
<head>

<script src="https://assets.xbox.com/xbcservicewebwww-nondfs-2109-22111-0-0-main-rolling/www/js/silentauth.js"></script>
    <!-- Third party scripts and code linked to or referenced here are licensed to you by the third parties that own such code, not by Microsoft, see ASP.NET Ajax CDN Terms of Use – http://www.asp.net/ajaxlibrary/CDN.ashx. -->
<script src="https://assets.xbox.com/xbcservicewebwww-nondfs-2109-22111-0-0-main-rolling/shell/js/adobeaudiencemanager.js"></script><script src="//assets.adobedtm.com/launch-ENbcb8955aa2f84046af210e3226cdda04.min.js?v=21092211100"></script>
    <!--
v 2108.13181.0.0
s AdERLDvRemqNPpXwaxc+/uv14Lp7cRKr9ytVV1MFOkM=
r 0a0c919b-112f-4799-bda0-b03d1e712318
-->
    <link href="/bundles/xboxonecommon?v=ttJAZKo5Wwy9GKdJ-bbm687UKhoxCgl2kj9WY3GqbCM1" rel="stylesheet"/>
<link href="/bundles/xboxstyles?v=uvTrYArEsN72wKE-UXK_lPNVn4DMI-FEIGRjiSKPrX41" rel="stylesheet"/>

    
<link href="/bundles/UhfMwfOverrides?v=kJx0j-t7cNiHsN_h0yR1lKXO12UiMFMKonWmLXehXs01" rel="stylesheet"/>

    <meta charset="utf-8" />
    <meta name="ms.locale" content="" />
    <title></title>
    <script>
        
        (function () {
            var html5Elements = ['article', 'section', 'header', 'nav', 'footer', 'aside'];
            for (var i = 0; i < html5Elements.length; i++) {
                document.createElement(html5Elements[i]);
            }
        })();
    </script>

    <!-- Third party scripts and code linked to or referenced here are licensed to you by the third parties that own such code, not by Microsoft, see ASP.NET Ajax CDN Terms of Use – http://www.asp.net/ajaxlibrary/CDN.ashx. -->
    <script src="https://assets.xbox.com/xbcservicewebwww-nondfs-2109-22111-0-0-main-rolling/shell/js/jquery-1.8.3.min.js"></script>
    <script>
        jQuery.curCSS = function (element, prop, val) {
            return jQuery(element).css(prop, val);
        };
    </script>
    <!-- Render UHF css and scripts in head -->
<link rel="stylesheet" href="https://www.microsoft.com/onerfstatics/marketingsites-wcus-prod/west-european/shell/_scrf/css/themes=default.device=uplevel_web_pc/79-4cdd0a/33-ae3d41/a5-4bf7a2/13-8e1ceb/81-32f0c0/5c-b7b685/dd-4224e1/ef-a24652?ver=2.0&amp;_cf=20210618" type="text/css" media="all" /><link rel='stylesheet' href='https://statics-marketingsites-wcus-ms-com.akamaized.net/statics/override.css' type='text/css' />
<script src="https://www.microsoft.com/onerfstatics/marketingsites-wcus-prod/shell/_scrf/js/themes=default/8e-e88b64/93-04b71e/dd-2cee44/49-a00ab0/92-02e55d/7c-dcea75/75-fca72d/ed-e77ee7/d5-bf34c0/a9-078595/7a-7ea8cc/2d-40bdad/23-e8cd2b/96-eb5423/e6-6b0cce/d1-98d78a/a0-23c4ba/a7-f7a340/48-6ed936/2e-ca165a/fc-169dd8/8e-60935c/87-fecbed/96-6ed6eb/c3-eb62e0/ad-ffd6bf/35-621acc/b0-07f293/1e-9d9d16/52-f0367f/1f-b57352/c3-e25a15/e1-ed258e/20-0b10e2/6b-0f1117/fb-5e9831/37-8473b9?ver=2.0&_cf=20210618&iife=1"></script><script src="https://mem.gfx.ms/meversion?partner=XboxcomUHF&market=en-us&uhf=1" defer></script>
    <script src="https://assets.xbox.com/xbcservicewebwww-nondfs-2109-22111-0-0-main-rolling/minified/shell/js/legacylayout.min.js"></script>
    <!-- [Begin] JSLL script includes -->
    <script src="https://az725175.vo.msecnd.net/scripts/jsll-4.js" type="text/javascript"></script>

    <script type="text/javascript">
       
        window.consentRequired = false;


        window.wcpCallBackValue = {
            Required: true,
            Analytics:   true,
            SocialMedia: true,
            Advertising: true
        };

        var initJsll = function () {
            var appId = "XboxWeb";
            if (window.location.hostname.match(/^support/)) {
                appId += "Support";
            }
            var environment = 'test';
            var isprod = 'True';
            if (isprod.toLowerCase() === 'true') {
                environment = 'prod';
            }
            var pathName = window.location.pathname.toLowerCase();
            var market = pathName.toString().replace(/^\/(..\-..).*/i, "$1");
            var path = pathName.replace(/^\/..(\-..)?\/?(.*)/i, "$2");
            var hostname = window.location.hostname.replace(/\.xbox\.com$/i, "");
            var pageName = path.replace(/\/+$/, "");
            pageName = hostname + "/" + pageName;
            var dirs = path.split("/");
            var pageType = dirs[0];
            if (pageName.match(/^$/)) {
                pageName = "home";
                pageType = "home";
            }
            var config = {
                isLoggedIn: false,
                shareAuthStatus: true,
                authMethod: 1,
                syncMuid: (wcpCallBackValue.Analytics && wcpCallBackValue.SocialMedia && wcpCallBackValue.Advertising),
                autoCapture: {
            scroll: true,
                    lineage: true,
                    resize: true
                },
                coreData: {
            appId: appId,
                    env: environment,
                    pageName: pageName,
                    pageType: pageType,
                    market: market,
                    pageTags: { "browserGroup": "WindowsNT.Chrome" }
            },
                callback: {
            userConsentDetailsCallback: function () { return wcpCallBackValue; } }
            };
            awa.init(config);
        }

        initJsll();
    </script>
    <!-- [End] JSLL script includes -->
    
    <script>
        define('capiConfig', [], function () {
            return {
                isEnabled: false
            }
        });
    </script>
    <script src="https://assets.xbox.com/xbcservicewebwww-nondfs-2109-22111-0-0-main-rolling/minified/shell/js/capi.min.js"></script>

    
    <link href="/bundles/xboxsplash?v=VD0QqxGjuY-LcQyaH_-ZQRX0toorB3DDcNot8eiX_nA1" rel="stylesheet"/>

    

<script src="https://assets.xbox.com/xbcservicewebwww-nondfs-2109-22111-0-0-main-rolling/minified/shell/js/silverlight.min.js"></script>
<script src="https://assets.xbox.com/xbcservicewebwww-nondfs-2109-22111-0-0-main-rolling/minified/shell/js/videoplayer.min.js"></script>
<script type="text/javascript">
    (function(window) {
        var xbox = window.xbox = window.xbox || { };
        xbox.videoPlayer = xbox.videoPlayer || { };
        xbox.videoPlayer.txtPlaybackErrorTitle = 'Can\u0027t Play';
        xbox.videoPlayer.txtPlaybackErrorActiveXDescription = 'Can\u0027t play this content because ActiveX is disabled. Please enable ActiveX in your browser settings, then refresh this page to try again.';
        xbox.videoPlayer.txtPlaybackErrorGenericDescription = 'There was a problem playing this video. Try again later.';
        xbox.videoPlayer.txtPlaybackErrorUnsupportedBrowser = 'Silverlight is not supported in your browser.';
        xbox.videoPlayer.txtPlaybackErrorClose = 'Close';       
        xbox.videoPlayer.locale = {currentCulture: 'en-US', currentUICulture: 'en-US'};
    })(window);
</script>
    

<style>
.contentarea1 div, .contentarea2 div {
 display: none;
}
div.showrandom, div.showrandom div {
 display: block !important;
}
</style>

    






    
<link rel="shortcut icon" href="https://assets.xbox.com/xbcservicewebwww-nondfs-2109-22111-0-0-main-rolling/shell/images/favicon.ico" />
</head>
<body id="DocumentBody" >
    <script type="text/javascript">
        document.onreadystatechange = function () {
            if (document.readyState == "complete") {
                var item = document.querySelector("div#purchaseDiv");
                if (!!item && item.style.display === 'block') {
                    item.focus();
                }
            }
        }
    </script>
    <div id="bodycolumn">


    <div id="headerArea" class="uhf"  data-m='{"cN":"headerArea","cT":"Area_coreuiArea","id":"a1Body","sN":1,"aN":"Body"}'>
                <div id="headerRegion"      data-region-key="headerregion" data-m='{"cN":"headerRegion","cT":"Region_coreui-region","id":"r1a1","sN":1,"aN":"a1"}' >

    <div  id="headerUniversalHeader" data-m='{"cN":"headerUniversalHeader","cT":"Module_coreui-universalheader","id":"m1r1a1","sN":1,"aN":"r1a1"}'  data-module-id="Category|headerRegion|coreui-region|headerUniversalHeader|coreui-universalheader">
        





        <a id="uhfSkipToMain" class="m-skip-to-main" href="javascript:void(0)" data-href="#PageContent" tabindex="0" data-m='{"cN":"Skip to content_nonnav","id":"nn1m1r1a1","sN":1,"aN":"m1r1a1"}'>Skip to main content</a>


<header class="c-uhfh context-uhf no-js c-sgl-stck c-category-header " itemscope="itemscope" data-header-footprint="/XboxcomUHF/Xboxcomheader, fromService: True"   data-magict="true"  itemtype="http://schema.org/Organization">
    <div class="theme-light js-global-head f-closed  global-head-cont" data-m='{"cN":"Universal Header_cont","cT":"Container","id":"c2m1r1a1","sN":2,"aN":"m1r1a1"}'>
        <div class="c-uhfh-gcontainer-st">
            <button type="button" class="c-action-trigger c-glyph glyph-global-nav-button" aria-label="All Microsoft expand to see list of Microsoft products and services" initialState-label="All Microsoft expand to see list of Microsoft products and services" toggleState-label="Close All Microsoft list" aria-expanded="false" data-m='{"cN":"Mobile menu button_nonnav","id":"nn1c2m1r1a1","sN":1,"aN":"c2m1r1a1"}'></button>
            <button type="button" class="c-action-trigger c-glyph glyph-arrow-htmllegacy c-close-search" aria-label="Close search" aria-expanded="false" data-m='{"cN":"Close Search_nonnav","id":"nn2c2m1r1a1","sN":2,"aN":"c2m1r1a1"}'></button>
                    <a id="uhfLogo" class="c-logo c-sgl-stk-uhfLogo" itemprop="url" href="https://www.microsoft.com" aria-label="Microsoft" data-m='{"cN":"GlobalNav_Logo_cont","cT":"Container","id":"c3c2m1r1a1","sN":3,"aN":"c2m1r1a1"}'>
                        <img alt="" itemprop="logo" class="c-image" src="https://img-prod-cms-rt-microsoft-com.akamaized.net/cms/api/am/imageFileData/RE1Mu3b?ver=5c31" role="presentation" aria-hidden="true" />
                        <span itemprop="name" role="presentation" aria-hidden="true">Microsoft</span>
                    </a>
            <div class="f-mobile-title">
                <button type="button" class="c-action-trigger c-glyph glyph-chevron-left" aria-label="See more menu options" data-m='{"cN":"Mobile back button_nonnav","id":"nn4c2m1r1a1","sN":4,"aN":"c2m1r1a1"}'></button>
                <span data-global-title="Microsoft home" class="js-mobile-title">Xbox</span>
                <button type="button" class="c-action-trigger c-glyph glyph-chevron-right" aria-label="See more menu options" data-m='{"cN":"Mobile forward button_nonnav","id":"nn5c2m1r1a1","sN":5,"aN":"c2m1r1a1"}'></button>
            </div>
                    <div class="c-show-pipe x-hidden-vp-mobile-st">
                        <a id="uhfCatLogo" class="c-logo c-cat-logo" href="https://www.xbox.com/en-US?xr=mebarnav" aria-label="Xbox" itemprop="url" data-m='{"cN":"CatNav_Xbox_nav","id":"n6c2m1r1a1","sN":6,"aN":"c2m1r1a1"}'>
                                <img itemprop="cat-logo" alt="Xbox" src="https://img-prod-cms-rt-microsoft-com.akamaized.net/cms/api/am/imageFileData/RW4ESm?ver=c63e" role="presentation" />
                                <div class=".c-uhf-img-tooltip">
                                    <span class="c-uhf-tooltiptext" role="tooltip">Xbox Home</span>
                                </div>
                        </a>
                    </div>
                <div class="cat-logo-button-cont x-hidden">
                        <button type="button" id="uhfCatLogoButton" class="c-cat-logo-button c-cat-logo-img x-hidden" aria-expanded="false" aria-label="Xbox" data-m='{"cN":"Xbox_nonnav","id":"nn7c2m1r1a1","sN":7,"aN":"c2m1r1a1"}'>
                        </button>
                </div>



                    <nav id="uhf-g-nav" aria-label="Contextual menu" class="c-uhfh-gnav" data-m='{"cN":"Category nav_cont","cT":"Container","id":"c8c2m1r1a1","sN":8,"aN":"c2m1r1a1"}'>
            <ul class="js-paddle-items">
                    <li class="single-link js-nav-menu x-hidden-none-mobile-vp uhf-menu-item">
                        <a class="c-uhf-nav-link" href="https://www.xbox.com/en-US?xr=mebarnav" data-m='{"cN":"CatNav_Home_nav","id":"n1c8c2m1r1a1","sN":1,"aN":"c8c2m1r1a1"}' > Home </a>
                    </li>
                                        <li class="nested-menu uhf-menu-item">
                            <div class="c-uhf-menu js-nav-menu">
                                <button type="button" id="c-shellmenu_56"  aria-expanded="false" data-m='{"cN":"CatNav_Game_Pass​_nonnav","id":"nn2c8c2m1r1a1","sN":2,"aN":"c8c2m1r1a1"}'>Game Pass​ </button>

                                <ul class="" data-class-idn="" aria-hidden="true" data-m='{"cN":"Game_Pass​_cont","cT":"Container","id":"c3c8c2m1r1a1","sN":3,"aN":"c8c2m1r1a1"}'>
        <li class="js-nav-menu single-link" data-m='{"cN":"Overview​_cont","cT":"Container","id":"c1c3c8c2m1r1a1","sN":1,"aN":"c3c8c2m1r1a1"}'>
            <a id="c-shellmenu_57" class="js-subm-uhf-nav-link" href="https://www.xbox.com/en-US/xbox-game-pass?xr=shellnav" data-m='{"cN":"CatNav_Overview​_nav","id":"n1c1c3c8c2m1r1a1","sN":1,"aN":"c1c3c8c2m1r1a1"}'>Overview​</a>
            
        </li>
        <li class="js-nav-menu single-link" data-m='{"cN":"Browse_Games​​_cont","cT":"Container","id":"c2c3c8c2m1r1a1","sN":2,"aN":"c3c8c2m1r1a1"}'>
            <a id="c-shellmenu_58" class="js-subm-uhf-nav-link" href="https://www.xbox.com/en-US/xbox-game-pass/games?xr=shellnav" data-m='{"cN":"CatNav_Browse_Games​​_nav","id":"n1c2c3c8c2m1r1a1","sN":1,"aN":"c2c3c8c2m1r1a1"}'>Browse Games​​</a>
            
        </li>
        <li class="js-nav-menu single-link" data-m='{"cN":"PC_Games_Plan​​_cont","cT":"Container","id":"c3c3c8c2m1r1a1","sN":3,"aN":"c3c8c2m1r1a1"}'>
            <a id="c-shellmenu_59" class="js-subm-uhf-nav-link" href="https://www.xbox.com/en-US/xbox-game-pass/pc-game-pass?xr=shellnav" data-m='{"cN":"CatNav_PC_Games_Plan​​_nav","id":"n1c3c3c8c2m1r1a1","sN":1,"aN":"c3c3c8c2m1r1a1"}'>PC Game Pass​​</a>
            
        </li>
        <li class="js-nav-menu single-link" data-m='{"cN":"Cloud_gaming​_cont","cT":"Container","id":"c4c3c8c2m1r1a1","sN":4,"aN":"c3c8c2m1r1a1"}'>
            <a id="c-shellmenu_60" class="js-subm-uhf-nav-link" href="https://www.xbox.com/en-US/xbox-game-pass/cloud-gaming?xr=shellnav" data-m='{"cN":"CatNav_Cloud_gaming​_nav","id":"n1c4c3c8c2m1r1a1","sN":1,"aN":"c4c3c8c2m1r1a1"}'>Xbox Cloud Gaming (Beta)​</a>
            
        </li>
        <li class="js-nav-menu single-link" data-m='{"cN":"Xbox_Live_Gold​​​_cont","cT":"Container","id":"c5c3c8c2m1r1a1","sN":5,"aN":"c3c8c2m1r1a1"}'>
            <a id="c-shellmenu_61" class="js-subm-uhf-nav-link" href="https://www.xbox.com/en-US/live/gold?xr=shellnav" data-m='{"cN":"CatNav_Xbox_Live_Gold​​​_nav","id":"n1c5c3c8c2m1r1a1","sN":1,"aN":"c5c3c8c2m1r1a1"}'>Xbox Live Gold​​​</a>
            
        </li>
                                                    
                                </ul>
                            </div>
                        </li>                        <li class="nested-menu uhf-menu-item">
                            <div class="c-uhf-menu js-nav-menu">
                                <button type="button" id="c-shellmenu_62"  aria-expanded="false" data-m='{"cN":"CatNav_Games_nonnav","id":"nn4c8c2m1r1a1","sN":4,"aN":"c8c2m1r1a1"}'>Games </button>

                                <ul class="f-multi-column f-multi-column-3" data-class-idn="f-multi-column f-multi-column-3" aria-hidden="true" data-m='{"cN":"Games_cont","cT":"Container","id":"c5c8c2m1r1a1","sN":5,"aN":"c8c2m1r1a1"}'>
<li class="f-sub-menu js-nav-menu nested-menu" data-m='{"cN":"Console Games_cont","cT":"Container","id":"c1c5c8c2m1r1a1","sN":1,"aN":"c5c8c2m1r1a1"}'>

    <span id="uhf-navspn-shellmenu_63-span" style="display:none"   f-multi-parent="true" aria-expanded="false" data-m='{"cN":"CatNav_Console Games_nonnav","id":"nn1c1c5c8c2m1r1a1","sN":1,"aN":"c1c5c8c2m1r1a1"}'>Console Games</span>
    <button id="uhf-navbtn-shellmenu_63-button" type="button"   f-multi-parent="true" aria-expanded="false" data-m='{"cN":"CatNav_Console Games_nonnav","id":"nn2c1c5c8c2m1r1a1","sN":2,"aN":"c1c5c8c2m1r1a1"}'>Console Games</button>
    <ul aria-hidden="true" aria-labelledby="uhf-navspn-shellmenu_63-span">
        <li class="js-nav-menu single-link" data-m='{"cN":"Shop all console games_cont","cT":"Container","id":"c3c1c5c8c2m1r1a1","sN":3,"aN":"c1c5c8c2m1r1a1"}'>
            <a id="shellmenu_64" class="js-subm-uhf-nav-link" href="https://www.xbox.com/en-US/games/all-games?xr=shellnav" data-m='{"cN":"CatNav_Shop all console games_nav","id":"n1c3c1c5c8c2m1r1a1","sN":1,"aN":"c3c1c5c8c2m1r1a1"}'>Shop all console games</a>
            
        </li>
        <li class="js-nav-menu single-link" data-m='{"cN":"Optimized games_cont","cT":"Container","id":"c4c1c5c8c2m1r1a1","sN":4,"aN":"c1c5c8c2m1r1a1"}'>
            <a id="shellmenu_65" class="js-subm-uhf-nav-link" href="https://www.xbox.com/en-US/games/optimized?xr=shellnav" data-m='{"cN":"CatNav_Optimized games_nav","id":"n1c4c1c5c8c2m1r1a1","sN":1,"aN":"c4c1c5c8c2m1r1a1"}'>Optimized games</a>
            
        </li>
        <li class="js-nav-menu single-link" data-m='{"cN":"Backward compatible games_cont","cT":"Container","id":"c5c1c5c8c2m1r1a1","sN":5,"aN":"c1c5c8c2m1r1a1"}'>
            <a id="shellmenu_66" class="js-subm-uhf-nav-link" href="https://www.xbox.com/en-US/games/backward-compatibility?xr=shellnav" data-m='{"cN":"CatNav_Backward compatible games_nav","id":"n1c5c1c5c8c2m1r1a1","sN":1,"aN":"c5c1c5c8c2m1r1a1"}'>Backward compatible games</a>
            
        </li>
        <li class="js-nav-menu single-link" data-m='{"cN":"Games with Gold_cont","cT":"Container","id":"c6c1c5c8c2m1r1a1","sN":6,"aN":"c1c5c8c2m1r1a1"}'>
            <a id="shellmenu_67" class="js-subm-uhf-nav-link" href="https://www.xbox.com/en-US/live/gold?xr=shellnav#gameswithgold" data-m='{"cN":"CatNav_Games with Gold_nav","id":"n1c6c1c5c8c2m1r1a1","sN":1,"aN":"c6c1c5c8c2m1r1a1"}'>Games with Gold</a>
            
        </li>
        <li class="js-nav-menu single-link" data-m='{"cN":"Deals with Gold_cont","cT":"Container","id":"c7c1c5c8c2m1r1a1","sN":7,"aN":"c1c5c8c2m1r1a1"}'>
            <a id="shellmenu_68" class="js-subm-uhf-nav-link" href="https://www.xbox.com/en-US/live/gold?xr=shellnav#dealswithgold" data-m='{"cN":"CatNav_Deals with Gold_nav","id":"n1c7c1c5c8c2m1r1a1","sN":1,"aN":"c7c1c5c8c2m1r1a1"}'>Deals with Gold</a>
            
        </li>
    </ul>
    
</li>
<li class="f-sub-menu js-nav-menu nested-menu" data-m='{"cN":"PC Games_cont","cT":"Container","id":"c2c5c8c2m1r1a1","sN":2,"aN":"c5c8c2m1r1a1"}'>

    <span id="uhf-navspn-shellmenu_69-span" style="display:none"   f-multi-parent="true" aria-expanded="false" data-m='{"cN":"CatNav_PC Games_nonnav","id":"nn1c2c5c8c2m1r1a1","sN":1,"aN":"c2c5c8c2m1r1a1"}'>PC Games</span>
    <button id="uhf-navbtn-shellmenu_69-button" type="button"   f-multi-parent="true" aria-expanded="false" data-m='{"cN":"CatNav_PC Games_nonnav","id":"nn2c2c5c8c2m1r1a1","sN":2,"aN":"c2c5c8c2m1r1a1"}'>PC Games</button>
    <ul aria-hidden="true" aria-labelledby="uhf-navspn-shellmenu_69-span">
        <li class="js-nav-menu single-link" data-m='{"cN":"Shop all PC games_cont","cT":"Container","id":"c3c2c5c8c2m1r1a1","sN":3,"aN":"c2c5c8c2m1r1a1"}'>
            <a id="shellmenu_70" class="js-subm-uhf-nav-link" href="https://www.xbox.com/en-US/games/all-games?cat=pcgames?xr=shellnav" data-m='{"cN":"CatNav_Shop all PC games_nav","id":"n1c3c2c5c8c2m1r1a1","sN":1,"aN":"c3c2c5c8c2m1r1a1"}'>Shop all PC games</a>
            
        </li>
        <li class="js-nav-menu single-link" data-m='{"cN":"PC gaming with Xbox_cont","cT":"Container","id":"c4c2c5c8c2m1r1a1","sN":4,"aN":"c2c5c8c2m1r1a1"}'>
            <a id="shellmenu_71" class="js-subm-uhf-nav-link" href="https://www.xbox.com/en-us/pc-gaming?xr=shellnav" data-m='{"cN":"CatNav_PC gaming with Xbox_nav","id":"n1c4c2c5c8c2m1r1a1","sN":1,"aN":"c4c2c5c8c2m1r1a1"}'>PC gaming with Xbox</a>
            
        </li>
        <li class="js-nav-menu single-link" data-m='{"cN":"PC Game Pass_cont","cT":"Container","id":"c5c2c5c8c2m1r1a1","sN":5,"aN":"c2c5c8c2m1r1a1"}'>
            <a id="shellmenu_72" class="js-subm-uhf-nav-link" href="https://www.xbox.com/en-US/xbox-game-pass/pc-game-pass?xr=shellnav" data-m='{"cN":"CatNav_PC Game Pass_nav","id":"n1c5c2c5c8c2m1r1a1","sN":1,"aN":"c5c2c5c8c2m1r1a1"}'>PC Game Pass</a>
            
        </li>
    </ul>
    
</li>
<li class="f-sub-menu js-nav-menu nested-menu" data-m='{"cN":"All Games_cont","cT":"Container","id":"c3c5c8c2m1r1a1","sN":3,"aN":"c5c8c2m1r1a1"}'>

    <span id="uhf-navspn-shellmenu_73-span" style="display:none"   f-multi-parent="true" aria-expanded="false" data-m='{"cN":"CatNav_All Games_nonnav","id":"nn1c3c5c8c2m1r1a1","sN":1,"aN":"c3c5c8c2m1r1a1"}'>All Games</span>
    <button id="uhf-navbtn-shellmenu_73-button" type="button"   f-multi-parent="true" aria-expanded="false" data-m='{"cN":"CatNav_All Games_nonnav","id":"nn2c3c5c8c2m1r1a1","sN":2,"aN":"c3c5c8c2m1r1a1"}'>All Games</button>
    <ul aria-hidden="true" aria-labelledby="uhf-navspn-shellmenu_73-span">
        <li class="js-nav-menu single-link" data-m='{"cN":"Games showcase_cont","cT":"Container","id":"c3c3c5c8c2m1r1a1","sN":3,"aN":"c3c5c8c2m1r1a1"}'>
            <a id="shellmenu_74" class="js-subm-uhf-nav-link" href="https://www.xbox.com/games?xr=shellnav" data-m='{"cN":"CatNav_Games showcase_nav","id":"n1c3c3c5c8c2m1r1a1","sN":1,"aN":"c3c3c5c8c2m1r1a1"}'>Explore games</a>
            
        </li>
        <li class="js-nav-menu single-link" data-m='{"cN":"Redeem Code_cont","cT":"Container","id":"c4c3c5c8c2m1r1a1","sN":4,"aN":"c3c5c8c2m1r1a1"}'>
            <a id="shellmenu_75" class="js-subm-uhf-nav-link" href="https://redeem.microsoft.com/enter?ref=xboxcom" data-m='{"cN":"CatNav_Redeem Code_nav","id":"n1c4c3c5c8c2m1r1a1","sN":1,"aN":"c4c3c5c8c2m1r1a1"}'>Redeem Code</a>
            
        </li>
        <li class="js-nav-menu single-link" data-m='{"cN":"Sales \u0026 Specials_cont","cT":"Container","id":"c5c3c5c8c2m1r1a1","sN":5,"aN":"c3c5c8c2m1r1a1"}'>
            <a id="shellmenu_76" class="js-subm-uhf-nav-link" href="https://www.xbox.com/en-US/promotions/sales/sales-and-specials?xr=shellnav" data-m='{"cN":"CatNav_Sales \u0026 Specials_nav","id":"n1c5c3c5c8c2m1r1a1","sN":1,"aN":"c5c3c5c8c2m1r1a1"}'>Sales &amp; Specials</a>
            
        </li>
    </ul>
    
</li>
                                                    
                                </ul>
                            </div>
                        </li>                        <li class="nested-menu uhf-menu-item">
                            <div class="c-uhf-menu js-nav-menu">
                                <button type="button" id="c-shellmenu_77"  aria-expanded="false" data-m='{"cN":"CatNav_Devices_nonnav","id":"nn6c8c2m1r1a1","sN":6,"aN":"c8c2m1r1a1"}'>Devices​ </button>

                                <ul class="f-multi-column f-multi-column-3" data-class-idn="f-multi-column f-multi-column-3" aria-hidden="true" data-m='{"cN":"Devices_cont","cT":"Container","id":"c7c8c2m1r1a1","sN":7,"aN":"c8c2m1r1a1"}'>
<li class="f-sub-menu js-nav-menu nested-menu" data-m='{"cN":"Consoles_cont","cT":"Container","id":"c1c7c8c2m1r1a1","sN":1,"aN":"c7c8c2m1r1a1"}'>

    <span id="uhf-navspn-shellmenu_78-span" style="display:none"   f-multi-parent="true" aria-expanded="false" data-m='{"cN":"CatNav_Consoles_nonnav","id":"nn1c1c7c8c2m1r1a1","sN":1,"aN":"c1c7c8c2m1r1a1"}'>Consoles</span>
    <button id="uhf-navbtn-shellmenu_78-button" type="button"   f-multi-parent="true" aria-expanded="false" data-m='{"cN":"CatNav_Consoles_nonnav","id":"nn2c1c7c8c2m1r1a1","sN":2,"aN":"c1c7c8c2m1r1a1"}'>Consoles</button>
    <ul aria-hidden="true" aria-labelledby="uhf-navspn-shellmenu_78-span">
        <li class="js-nav-menu single-link" data-m='{"cN":"Xbox consoles_cont","cT":"Container","id":"c3c1c7c8c2m1r1a1","sN":3,"aN":"c1c7c8c2m1r1a1"}'>
            <a id="Xbox_consoles" class="js-subm-uhf-nav-link" href="https://www.xbox.com/en-US/consoles?xr=shellnav" data-m='{"cN":"CatNav_Xbox consoles_nav","id":"n1c3c1c7c8c2m1r1a1","sN":1,"aN":"c3c1c7c8c2m1r1a1"}'>Xbox consoles</a>
            
        </li>
        <li class="js-nav-menu single-link" data-m='{"cN":"Xbox Series X_cont","cT":"Container","id":"c4c1c7c8c2m1r1a1","sN":4,"aN":"c1c7c8c2m1r1a1"}'>
            <a id="shellmenu_80" class="js-subm-uhf-nav-link" href="https://www.xbox.com/en-US/consoles/xbox-series-x?xr=shellnav" data-m='{"cN":"CatNav_Xbox Series X_nav","id":"n1c4c1c7c8c2m1r1a1","sN":1,"aN":"c4c1c7c8c2m1r1a1"}'>Xbox Series X</a>
            
        </li>
        <li class="js-nav-menu single-link" data-m='{"cN":"Xbox Series S_cont","cT":"Container","id":"c5c1c7c8c2m1r1a1","sN":5,"aN":"c1c7c8c2m1r1a1"}'>
            <a id="shellmenu_81" class="js-subm-uhf-nav-link" href="https://www.xbox.com/en-US/consoles/xbox-series-s?xr=shellnav" data-m='{"cN":"CatNav_Xbox Series S_nav","id":"n1c5c1c7c8c2m1r1a1","sN":1,"aN":"c5c1c7c8c2m1r1a1"}'>Xbox Series S</a>
            
        </li>
        <li class="js-nav-menu single-link" data-m='{"cN":"Xbox All Access_cont","cT":"Container","id":"c6c1c7c8c2m1r1a1","sN":6,"aN":"c1c7c8c2m1r1a1"}'>
            <a id="shellmenu_82" class="js-subm-uhf-nav-link" href="https://www.xbox.com/en-US/xbox-all-access?xr=shellnav" data-m='{"cN":"CatNav_Xbox All Access_nav","id":"n1c6c1c7c8c2m1r1a1","sN":1,"aN":"c6c1c7c8c2m1r1a1"}'>Xbox All Access</a>
            
        </li>
        <li class="js-nav-menu single-link" data-m='{"cN":"Shop all consoles_cont","cT":"Container","id":"c7c1c7c8c2m1r1a1","sN":7,"aN":"c1c7c8c2m1r1a1"}'>
            <a id="shellmenu_83" class="js-subm-uhf-nav-link" href="https://www.xbox.com/en-US/consoles/all-consoles?xr=shellnav" data-m='{"cN":"CatNav_Shop all consoles_nav","id":"n1c7c1c7c8c2m1r1a1","sN":1,"aN":"c7c1c7c8c2m1r1a1"}'>Shop all consoles</a>
            
        </li>
        <li class="js-nav-menu single-link" data-m='{"cN":"Help Me Choose_cont","cT":"Container","id":"c8c1c7c8c2m1r1a1","sN":8,"aN":"c1c7c8c2m1r1a1"}'>
            <a id="Help_Me_Choose" class="js-subm-uhf-nav-link" href="https://www.xbox.com/en-US/consoles/help-me-choose?xr=shellnav" data-m='{"cN":"CatNav_Help Me Choose_nav","id":"n1c8c1c7c8c2m1r1a1","sN":1,"aN":"c8c1c7c8c2m1r1a1"}'>Help Me Choose</a>
            
        </li>
        <li class="js-nav-menu single-link" data-m='{"cN":"Where to buy_cont","cT":"Container","id":"c9c1c7c8c2m1r1a1","sN":9,"aN":"c1c7c8c2m1r1a1"}'>
            <a id="shellmenu_85" class="js-subm-uhf-nav-link" href="https://www.xbox.com/en-US/where-to-buy?xr=shellnav" data-m='{"cN":"CatNav_Where to buy_nav","id":"n1c9c1c7c8c2m1r1a1","sN":1,"aN":"c9c1c7c8c2m1r1a1"}'>Where to buy</a>
            
        </li>
    </ul>
    
</li>
<li class="f-sub-menu js-nav-menu nested-menu" data-m='{"cN":"Accessories_cont","cT":"Container","id":"c2c7c8c2m1r1a1","sN":2,"aN":"c7c8c2m1r1a1"}'>

    <span id="uhf-navspn-shellmenu_86-span" style="display:none"   f-multi-parent="true" aria-expanded="false" data-m='{"cN":"CatNav_Accessories_nonnav","id":"nn1c2c7c8c2m1r1a1","sN":1,"aN":"c2c7c8c2m1r1a1"}'>Accessories</span>
    <button id="uhf-navbtn-shellmenu_86-button" type="button"   f-multi-parent="true" aria-expanded="false" data-m='{"cN":"CatNav_Accessories_nonnav","id":"nn2c2c7c8c2m1r1a1","sN":2,"aN":"c2c7c8c2m1r1a1"}'>Accessories</button>
    <ul aria-hidden="true" aria-labelledby="uhf-navspn-shellmenu_86-span">
        <li class="js-nav-menu single-link" data-m='{"cN":"Shop all accessories_cont","cT":"Container","id":"c3c2c7c8c2m1r1a1","sN":3,"aN":"c2c7c8c2m1r1a1"}'>
            <a id="shellmenu_87" class="js-subm-uhf-nav-link" href="https://www.xbox.com/en-US/accessories?xr=shellnav" data-m='{"cN":"CatNav_Shop all accessories_nav","id":"n1c3c2c7c8c2m1r1a1","sN":1,"aN":"c3c2c7c8c2m1r1a1"}'>Shop all accessories</a>
            
        </li>
        <li class="js-nav-menu single-link" data-m='{"cN":"Design your controller_cont","cT":"Container","id":"c4c2c7c8c2m1r1a1","sN":4,"aN":"c2c7c8c2m1r1a1"}'>
            <a id="shellmenu_88" class="js-subm-uhf-nav-link" href="https://xboxdesignlab.xbox.com?xr=shellnav" data-m='{"cN":"CatNav_Design your controller_nav","id":"n1c4c2c7c8c2m1r1a1","sN":1,"aN":"c4c2c7c8c2m1r1a1"}'>Design your controller</a>
            
        </li>
        <li class="js-nav-menu single-link" data-m='{"cN":"Controllers_cont","cT":"Container","id":"c5c2c7c8c2m1r1a1","sN":5,"aN":"c2c7c8c2m1r1a1"}'>
            <a id="shellmenu_89" class="js-subm-uhf-nav-link" href="https://www.xbox.com/en-US/accessories?xr=shellnav#controllers" data-m='{"cN":"CatNav_Controllers_nav","id":"n1c5c2c7c8c2m1r1a1","sN":1,"aN":"c5c2c7c8c2m1r1a1"}'>Controllers</a>
            
        </li>
        <li class="js-nav-menu single-link" data-m='{"cN":"Headsets_cont","cT":"Container","id":"c6c2c7c8c2m1r1a1","sN":6,"aN":"c2c7c8c2m1r1a1"}'>
            <a id="shellmenu_90" class="js-subm-uhf-nav-link" href="https://www.xbox.com/en-US/accessories?xr=shellnav#headsets" data-m='{"cN":"CatNav_Headsets_nav","id":"n1c6c2c7c8c2m1r1a1","sN":1,"aN":"c6c2c7c8c2m1r1a1"}'>Headsets</a>
            
        </li>
        <li class="js-nav-menu single-link" data-m='{"cN":"Hard drives \u0026 storage_cont","cT":"Container","id":"c7c2c7c8c2m1r1a1","sN":7,"aN":"c2c7c8c2m1r1a1"}'>
            <a id="shellmenu_91" class="js-subm-uhf-nav-link" href="https://www.xbox.com/en-US/accessories?xr=shellnav#harddrives" data-m='{"cN":"CatNav_Hard drives \u0026 storage_nav","id":"n1c7c2c7c8c2m1r1a1","sN":1,"aN":"c7c2c7c8c2m1r1a1"}'>Hard drives &amp; storage</a>
            
        </li>
        <li class="js-nav-menu single-link" data-m='{"cN":"Mobile gaming accessories_cont","cT":"Container","id":"c8c2c7c8c2m1r1a1","sN":8,"aN":"c2c7c8c2m1r1a1"}'>
            <a id="shellmenu_92" class="js-subm-uhf-nav-link" href="https://www.xbox.com/en-US/accessories?xr=shellnav#mobile" data-m='{"cN":"CatNav_Mobile gaming accessories_nav","id":"n1c8c2c7c8c2m1r1a1","sN":1,"aN":"c8c2c7c8c2m1r1a1"}'>Mobile gaming accessories</a>
            
        </li>
    </ul>
    
</li>
<li class="f-sub-menu js-nav-menu nested-menu" data-m='{"cN":"PC Devices_cont","cT":"Container","id":"c3c7c8c2m1r1a1","sN":3,"aN":"c7c8c2m1r1a1"}'>

    <span id="uhf-navspn-shellmenu_93-span" style="display:none"   f-multi-parent="true" aria-expanded="false" data-m='{"cN":"CatNav_PC Devices_nonnav","id":"nn1c3c7c8c2m1r1a1","sN":1,"aN":"c3c7c8c2m1r1a1"}'>PC Devices</span>
    <button id="uhf-navbtn-shellmenu_93-button" type="button"   f-multi-parent="true" aria-expanded="false" data-m='{"cN":"CatNav_PC Devices_nonnav","id":"nn2c3c7c8c2m1r1a1","sN":2,"aN":"c3c7c8c2m1r1a1"}'>PC Devices</button>
    <ul aria-hidden="true" aria-labelledby="uhf-navspn-shellmenu_93-span">
        <li class="js-nav-menu single-link" data-m='{"cN":"Gaming PCs_cont","cT":"Container","id":"c3c3c7c8c2m1r1a1","sN":3,"aN":"c3c7c8c2m1r1a1"}'>
            <a id="shellmenu_94" class="js-subm-uhf-nav-link" href="https://www.xbox.com/en-US/pc-gaming?xr=shellnav" data-m='{"cN":"CatNav_Gaming PCs_nav","id":"n1c3c3c7c8c2m1r1a1","sN":1,"aN":"c3c3c7c8c2m1r1a1"}'>Gaming PCs</a>
            
        </li>
    </ul>
    
</li>
                                                    
                                </ul>
                            </div>
                        </li>                        <li class="single-link js-nav-menu uhf-menu-item">
                            <a id="c-shellmenu_95" class="c-uhf-nav-link" href="https://www.xbox.com/en-US/play?xr=shellnav" data-m='{"cN":"CatNav_Play_nav","id":"n8c8c2m1r1a1","sN":8,"aN":"c8c2m1r1a1"}'>Play</a>
                        </li>
                        <li class="nested-menu uhf-menu-item">
                            <div class="c-uhf-menu js-nav-menu">
                                <button type="button" id="c-shellmenu_96"  aria-expanded="false" data-m='{"cN":"CatNav_Community_nonnav","id":"nn9c8c2m1r1a1","sN":9,"aN":"c8c2m1r1a1"}'>Community </button>

                                <ul class="f-multi-column f-multi-column-4" data-class-idn="f-multi-column f-multi-column-4" aria-hidden="true" data-m='{"cN":"Community_cont","cT":"Container","id":"c10c8c2m1r1a1","sN":10,"aN":"c8c2m1r1a1"}'>
<li class="f-sub-menu js-nav-menu nested-menu" data-m='{"cN":"Community_cont","cT":"Container","id":"c1c10c8c2m1r1a1","sN":1,"aN":"c10c8c2m1r1a1"}'>

    <span id="uhf-navspn-shellmenu_97-span" style="display:none"   f-multi-parent="true" aria-expanded="false" data-m='{"cN":"CatNav_Community_nonnav","id":"nn1c1c10c8c2m1r1a1","sN":1,"aN":"c1c10c8c2m1r1a1"}'>Community</span>
    <button id="uhf-navbtn-shellmenu_97-button" type="button"   f-multi-parent="true" aria-expanded="false" data-m='{"cN":"CatNav_Community_nonnav","id":"nn2c1c10c8c2m1r1a1","sN":2,"aN":"c1c10c8c2m1r1a1"}'>Community</button>
    <ul aria-hidden="true" aria-labelledby="uhf-navspn-shellmenu_97-span">
        <li class="js-nav-menu single-link" data-m='{"cN":"Xbox community_cont","cT":"Container","id":"c3c1c10c8c2m1r1a1","sN":3,"aN":"c1c10c8c2m1r1a1"}'>
            <a id="shellmenu_98" class="js-subm-uhf-nav-link" href="https://www.xbox.com/en-US/community?xr=shellnav" data-m='{"cN":"CatNav_Xbox community_nav","id":"n1c3c1c10c8c2m1r1a1","sN":1,"aN":"c3c1c10c8c2m1r1a1"}'>Xbox community</a>
            
        </li>
        <li class="js-nav-menu single-link" data-m='{"cN":"Multiplayer gaming_cont","cT":"Container","id":"c4c1c10c8c2m1r1a1","sN":4,"aN":"c1c10c8c2m1r1a1"}'>
            <a id="shellmenu_99" class="js-subm-uhf-nav-link" href="https://www.xbox.com/en-US/live/gold?xr=shellnav" data-m='{"cN":"CatNav_Multiplayer gaming_nav","id":"n1c4c1c10c8c2m1r1a1","sN":1,"aN":"c4c1c10c8c2m1r1a1"}'>Multiplayer gaming</a>
            
        </li>
        <li class="js-nav-menu single-link" data-m='{"cN":"Esports_cont","cT":"Container","id":"c5c1c10c8c2m1r1a1","sN":5,"aN":"c1c10c8c2m1r1a1"}'>
            <a id="shellmenu_100" class="js-subm-uhf-nav-link" href="https://www.xbox.com/en-US/community/esports?xr=shellnav" data-m='{"cN":"CatNav_Esports_nav","id":"n1c5c1c10c8c2m1r1a1","sN":1,"aN":"c5c1c10c8c2m1r1a1"}'>Esports</a>
            
        </li>
        <li class="js-nav-menu single-link" data-m='{"cN":"Xbox News_cont","cT":"Container","id":"c6c1c10c8c2m1r1a1","sN":6,"aN":"c1c10c8c2m1r1a1"}'>
            <a id="shellmenu_101" class="js-subm-uhf-nav-link" href="https://news.xbox.com/en-us/?xr=shellnav" data-m='{"cN":"CatNav_Xbox News_nav","id":"n1c6c1c10c8c2m1r1a1","sN":1,"aN":"c6c1c10c8c2m1r1a1"}'>Xbox News</a>
            
        </li>
        <li class="js-nav-menu single-link" data-m='{"cN":"Sustainability_cont","cT":"Container","id":"c7c1c10c8c2m1r1a1","sN":7,"aN":"c1c10c8c2m1r1a1"}'>
            <a id="shellmenu_102" class="js-subm-uhf-nav-link" href="https://www.xbox.com/en-US/community/sustainability?xr=shellnav" data-m='{"cN":"CatNav_Sustainability_nav","id":"n1c7c1c10c8c2m1r1a1","sN":1,"aN":"c7c1c10c8c2m1r1a1"}'>Sustainability</a>
            
        </li>
    </ul>
    
</li>
<li class="f-sub-menu js-nav-menu nested-menu" data-m='{"cN":"For Everyone_cont","cT":"Container","id":"c2c10c8c2m1r1a1","sN":2,"aN":"c10c8c2m1r1a1"}'>

    <span id="uhf-navspn-shellmenu_103-span" style="display:none"   f-multi-parent="true" aria-expanded="false" data-m='{"cN":"CatNav_For Everyone_nonnav","id":"nn1c2c10c8c2m1r1a1","sN":1,"aN":"c2c10c8c2m1r1a1"}'>For Everyone</span>
    <button id="uhf-navbtn-shellmenu_103-button" type="button"   f-multi-parent="true" aria-expanded="false" data-m='{"cN":"CatNav_For Everyone_nonnav","id":"nn2c2c10c8c2m1r1a1","sN":2,"aN":"c2c10c8c2m1r1a1"}'>For Everyone</button>
    <ul aria-hidden="true" aria-labelledby="uhf-navspn-shellmenu_103-span">
        <li class="js-nav-menu single-link" data-m='{"cN":"Our philosophy_cont","cT":"Container","id":"c3c2c10c8c2m1r1a1","sN":3,"aN":"c2c10c8c2m1r1a1"}'>
            <a id="shellmenu_104" class="js-subm-uhf-nav-link" href="https://www.xbox.com/community/for-everyone?xr=shellnav" data-m='{"cN":"CatNav_Our philosophy_nav","id":"n1c3c2c10c8c2m1r1a1","sN":1,"aN":"c3c2c10c8c2m1r1a1"}'>Our philosophy</a>
            
        </li>
        <li class="js-nav-menu single-link" data-m='{"cN":"Responsible gaming_cont","cT":"Container","id":"c4c2c10c8c2m1r1a1","sN":4,"aN":"c2c10c8c2m1r1a1"}'>
            <a id="shellmenu_105" class="js-subm-uhf-nav-link" href="https://www.xbox.com/en-US/community/for-everyone/responsible-gaming?xr=shellnav" data-m='{"cN":"CatNav_Responsible gaming_nav","id":"n1c4c2c10c8c2m1r1a1","sN":1,"aN":"c4c2c10c8c2m1r1a1"}'>Responsible gaming</a>
            
        </li>
        <li class="js-nav-menu single-link" data-m='{"cN":"Accessible gaming_cont","cT":"Container","id":"c5c2c10c8c2m1r1a1","sN":5,"aN":"c2c10c8c2m1r1a1"}'>
            <a id="shellmenu_106" class="js-subm-uhf-nav-link" href="https://www.xbox.com/en-US/community/for-everyone/accessibility?xr=shellnav" data-m='{"cN":"CatNav_Accessible gaming_nav","id":"n1c5c2c10c8c2m1r1a1","sN":1,"aN":"c5c2c10c8c2m1r1a1"}'>Accessible gaming</a>
            
        </li>
        <li class="js-nav-menu single-link" data-m='{"cN":"Community standards_cont","cT":"Container","id":"c6c2c10c8c2m1r1a1","sN":6,"aN":"c2c10c8c2m1r1a1"}'>
            <a id="shellmenu_107" class="js-subm-uhf-nav-link" href="https://www.xbox.com/en-US/legal/community-standards?xr=shellnav" data-m='{"cN":"CatNav_Community standards_nav","id":"n1c6c2c10c8c2m1r1a1","sN":1,"aN":"c6c2c10c8c2m1r1a1"}'>Community standards</a>
            
        </li>
    </ul>
    
</li>
<li class="f-sub-menu js-nav-menu nested-menu" data-m='{"cN":"Xbox Gear Shop_cont","cT":"Container","id":"c3c10c8c2m1r1a1","sN":3,"aN":"c10c8c2m1r1a1"}'>

    <span id="uhf-navspn-shellmenu_108-span" style="display:none"   f-multi-parent="true" aria-expanded="false" data-m='{"cN":"CatNav_Xbox Gear Shop_nonnav","id":"nn1c3c10c8c2m1r1a1","sN":1,"aN":"c3c10c8c2m1r1a1"}'>Xbox Gear Shop</span>
    <button id="uhf-navbtn-shellmenu_108-button" type="button"   f-multi-parent="true" aria-expanded="false" data-m='{"cN":"CatNav_Xbox Gear Shop_nonnav","id":"nn2c3c10c8c2m1r1a1","sN":2,"aN":"c3c10c8c2m1r1a1"}'>Xbox Gear Shop</button>
    <ul aria-hidden="true" aria-labelledby="uhf-navspn-shellmenu_108-span">
        <li class="js-nav-menu single-link" data-m='{"cN":"Shop gear_cont","cT":"Container","id":"c3c3c10c8c2m1r1a1","sN":3,"aN":"c3c10c8c2m1r1a1"}'>
            <a id="shellmenu_109" class="js-subm-uhf-nav-link" href="https://gear.xbox.com/?xr=shellnav" data-m='{"cN":"CatNav_Shop gear_nav","id":"n1c3c3c10c8c2m1r1a1","sN":1,"aN":"c3c3c10c8c2m1r1a1"}'>Shop gear</a>
            
        </li>
    </ul>
    
</li>
<li class="f-sub-menu js-nav-menu nested-menu" data-m='{"cN":"Apps \u0026 Entertainment_cont","cT":"Container","id":"c4c10c8c2m1r1a1","sN":4,"aN":"c10c8c2m1r1a1"}'>

    <span id="uhf-navspn-shellmenu_110-span" style="display:none"   f-multi-parent="true" aria-expanded="false" data-m='{"cN":"CatNav_Apps \u0026 Entertainment_nonnav","id":"nn1c4c10c8c2m1r1a1","sN":1,"aN":"c4c10c8c2m1r1a1"}'>Apps &amp; Entertainment</span>
    <button id="uhf-navbtn-shellmenu_110-button" type="button"   f-multi-parent="true" aria-expanded="false" data-m='{"cN":"CatNav_Apps \u0026 Entertainment_nonnav","id":"nn2c4c10c8c2m1r1a1","sN":2,"aN":"c4c10c8c2m1r1a1"}'>Apps &amp; Entertainment</button>
    <ul aria-hidden="true" aria-labelledby="uhf-navspn-shellmenu_110-span">
        <li class="js-nav-menu single-link" data-m='{"cN":"Xbox app for mobile_cont","cT":"Container","id":"c3c4c10c8c2m1r1a1","sN":3,"aN":"c4c10c8c2m1r1a1"}'>
            <a id="shellmenu_111" class="js-subm-uhf-nav-link" href="https://www.xbox.com/en-US/apps/xbox-app-for-mobile?xr=shellnav" data-m='{"cN":"CatNav_Xbox app for mobile_nav","id":"n1c3c4c10c8c2m1r1a1","sN":1,"aN":"c3c4c10c8c2m1r1a1"}'>Xbox app for mobile</a>
            
        </li>
        <li class="js-nav-menu single-link" data-m='{"cN":"Xbox app for Windows PC_cont","cT":"Container","id":"c4c4c10c8c2m1r1a1","sN":4,"aN":"c4c10c8c2m1r1a1"}'>
            <a id="shellmenu_112" class="js-subm-uhf-nav-link" href="https://www.xbox.com/en-US/apps/xbox-app-for-pc?xr=shellnav" data-m='{"cN":"CatNav_Xbox app for Windows PC_nav","id":"n1c4c4c10c8c2m1r1a1","sN":1,"aN":"c4c4c10c8c2m1r1a1"}'>Xbox app for Windows PC</a>
            
        </li>
        <li class="js-nav-menu single-link" data-m='{"cN":"Xbox Game Pass mobile app_cont","cT":"Container","id":"c5c4c10c8c2m1r1a1","sN":5,"aN":"c4c10c8c2m1r1a1"}'>
            <a id="shellmenu_113" class="js-subm-uhf-nav-link" href="https://www.xbox.com/en-US/apps/xbox-game-pass-mobile-app?xr=shellnav" data-m='{"cN":"CatNav_Xbox Game Pass mobile app_nav","id":"n1c5c4c10c8c2m1r1a1","sN":1,"aN":"c5c4c10c8c2m1r1a1"}'>Xbox Game Pass mobile app</a>
            
        </li>
        <li class="js-nav-menu single-link" data-m='{"cN":"Xbox Family Settings app_cont","cT":"Container","id":"c6c4c10c8c2m1r1a1","sN":6,"aN":"c4c10c8c2m1r1a1"}'>
            <a id="shellmenu_114" class="js-subm-uhf-nav-link" href="https://www.xbox.com/en-US/apps/family-settings-app?xr=shellnav" data-m='{"cN":"CatNav_Xbox Family Settings app_nav","id":"n1c6c4c10c8c2m1r1a1","sN":1,"aN":"c6c4c10c8c2m1r1a1"}'>Xbox Family Settings app</a>
            
        </li>
        <li class="js-nav-menu single-link" data-m='{"cN":"Console entertainment apps_cont","cT":"Container","id":"c7c4c10c8c2m1r1a1","sN":7,"aN":"c4c10c8c2m1r1a1"}'>
            <a id="shellmenu_115" class="js-subm-uhf-nav-link" href="https://www.xbox.com/en-US/entertainment/console-apps?xr=shellnav" data-m='{"cN":"CatNav_Console entertainment apps_nav","id":"n1c7c4c10c8c2m1r1a1","sN":1,"aN":"c7c4c10c8c2m1r1a1"}'>Console entertainment apps</a>
            
        </li>
    </ul>
    
</li>
                                                    
                                </ul>
                            </div>
                        </li>                        <li class="nested-menu uhf-menu-item">
                            <div class="c-uhf-menu js-nav-menu">
                                <button type="button" id="xboxSupport"  aria-expanded="false" data-m='{"cN":"CatNav_Support_nonnav","id":"nn11c8c2m1r1a1","sN":11,"aN":"c8c2m1r1a1"}'>Support </button>

                                <ul class="" data-class-idn="" aria-hidden="true" data-m='{"cN":"Support_cont","cT":"Container","id":"c12c8c2m1r1a1","sN":12,"aN":"c8c2m1r1a1"}'>
        <li class="js-nav-menu single-link" data-m='{"cN":"Support_SupportHome_MSXC_cont","cT":"Container","id":"c1c12c8c2m1r1a1","sN":1,"aN":"c12c8c2m1r1a1"}'>
            <a id="c-shellmenu_117" class="js-subm-uhf-nav-link" href="https://support.xbox.com/en-US/" data-m='{"cN":"CatNav_Support_SupportHome_MSXC_nav","id":"n1c1c12c8c2m1r1a1","sN":1,"aN":"c1c12c8c2m1r1a1"}'>Support home</a>
            
        </li>
        <li class="js-nav-menu single-link" data-m='{"cN":"Support_XboxLiveStatus_MSXC_cont","cT":"Container","id":"c2c12c8c2m1r1a1","sN":2,"aN":"c12c8c2m1r1a1"}'>
            <a id="c-shellmenu_118" class="js-subm-uhf-nav-link" href="https://support.xbox.com/en-US/xbox-live-status" data-m='{"cN":"CatNav_Support_XboxLiveStatus_MSXC_nav","id":"n1c2c12c8c2m1r1a1","sN":1,"aN":"c2c12c8c2m1r1a1"}'>Xbox status</a>
            
        </li>
<li class="f-sub-menu js-nav-menu nested-menu" data-m='{"cN":"Support_HelpTopics_MSXC_cont","cT":"Container","id":"c3c12c8c2m1r1a1","sN":3,"aN":"c12c8c2m1r1a1"}'>

    <span id="uhf-navspn-c-shellmenu_119-span" style="display:none"   aria-expanded="false" data-m='{"cN":"CatNav_Support_HelpTopics_MSXC_nonnav","id":"nn1c3c12c8c2m1r1a1","sN":1,"aN":"c3c12c8c2m1r1a1"}'>Help topics</span>
    <button id="uhf-navbtn-c-shellmenu_119-button" type="button"   aria-expanded="false" data-m='{"cN":"CatNav_Support_HelpTopics_MSXC_nonnav","id":"nn2c3c12c8c2m1r1a1","sN":2,"aN":"c3c12c8c2m1r1a1"}'>Help topics</button>
    <ul aria-hidden="true" aria-labelledby="uhf-navspn-c-shellmenu_119-span">
        <li class="js-nav-menu single-link" data-m='{"cN":"Support_AccountProfile_cont","cT":"Container","id":"c3c3c12c8c2m1r1a1","sN":3,"aN":"c3c12c8c2m1r1a1"}'>
            <a id="c-shellmenu_120" class="js-subm-uhf-nav-link" href="https://support.xbox.com/en-US/help/account-profile/browse" data-m='{"cN":"CatNav_Support_AccountProfile_nav","id":"n1c3c3c12c8c2m1r1a1","sN":1,"aN":"c3c3c12c8c2m1r1a1"}'>Account &amp; profile</a>
            
        </li>
        <li class="js-nav-menu single-link" data-m='{"cN":"Support_SubscriptionsBilling_MSXC_cont","cT":"Container","id":"c4c3c12c8c2m1r1a1","sN":4,"aN":"c3c12c8c2m1r1a1"}'>
            <a id="c-shellmenu_121" class="js-subm-uhf-nav-link" href="https://support.xbox.com/en-US/help/subscriptions-billing/browse" data-m='{"cN":"CatNav_Support_SubscriptionsBilling_MSXC_nav","id":"n1c4c3c12c8c2m1r1a1","sN":1,"aN":"c4c3c12c8c2m1r1a1"}'>Subscriptions &amp; billing</a>
            
        </li>
        <li class="js-nav-menu single-link" data-m='{"cN":"Support_HardwareNetworking_MSXC_cont","cT":"Container","id":"c5c3c12c8c2m1r1a1","sN":5,"aN":"c3c12c8c2m1r1a1"}'>
            <a id="c-shellmenu_122" class="js-subm-uhf-nav-link" href="https://support.xbox.com/en-US/help/hardware-network/browse" data-m='{"cN":"CatNav_Support_HardwareNetworking_MSXC_nav","id":"n1c5c3c12c8c2m1r1a1","sN":1,"aN":"c5c3c12c8c2m1r1a1"}'>Hardware &amp; networking</a>
            
        </li>
        <li class="js-nav-menu single-link" data-m='{"cN":"Support_FamilyOnlineSafety_MSXC_cont","cT":"Container","id":"c6c3c12c8c2m1r1a1","sN":6,"aN":"c3c12c8c2m1r1a1"}'>
            <a id="c-shellmenu_123" class="js-subm-uhf-nav-link" href="https://support.xbox.com/en-US/help/family-online-safety/browse" data-m='{"cN":"CatNav_Support_FamilyOnlineSafety_MSXC_nav","id":"n1c6c3c12c8c2m1r1a1","sN":1,"aN":"c6c3c12c8c2m1r1a1"}'>Family &amp; online safety</a>
            
        </li>
        <li class="js-nav-menu single-link" data-m='{"cN":"Support_GamesApps_MSXC_cont","cT":"Container","id":"c7c3c12c8c2m1r1a1","sN":7,"aN":"c3c12c8c2m1r1a1"}'>
            <a id="c-shellmenu_124" class="js-subm-uhf-nav-link" href="https://support.xbox.com/en-US/help/games-apps/browse" data-m='{"cN":"CatNav_Support_GamesApps_MSXC_nav","id":"n1c7c3c12c8c2m1r1a1","sN":1,"aN":"c7c3c12c8c2m1r1a1"}'>Games &amp; apps</a>
            
        </li>
        <li class="js-nav-menu single-link" data-m='{"cN":"Support_FriendsSocialActivity_MSXC_cont","cT":"Container","id":"c8c3c12c8c2m1r1a1","sN":8,"aN":"c3c12c8c2m1r1a1"}'>
            <a id="c-shellmenu_125" class="js-subm-uhf-nav-link" href="https://support.xbox.com/en-US/help/friends-social-activity/browse" data-m='{"cN":"CatNav_Support_FriendsSocialActivity_MSXC_nav","id":"n1c8c3c12c8c2m1r1a1","sN":1,"aN":"c8c3c12c8c2m1r1a1"}'>Friends &amp; social activity</a>
            
        </li>
    </ul>
    
</li>
        <li class="js-nav-menu single-link" data-m='{"cN":"Support_AccessibleGaming_MSXC_cont","cT":"Container","id":"c4c12c8c2m1r1a1","sN":4,"aN":"c12c8c2m1r1a1"}'>
            <a id="c-shellmenu_126" class="js-subm-uhf-nav-link" href="https://support.xbox.com/en-US/help/accessible-gaming" data-m='{"cN":"CatNav_Support_AccessibleGaming_MSXC_nav","id":"n1c4c12c8c2m1r1a1","sN":1,"aN":"c4c12c8c2m1r1a1"}'>Accessible gaming</a>
            
        </li>
        <li class="js-nav-menu single-link" data-m='{"cN":"Support_XboxSystemUpdates_MSXC_cont","cT":"Container","id":"c5c12c8c2m1r1a1","sN":5,"aN":"c12c8c2m1r1a1"}'>
            <a id="c-shellmenu_127" class="js-subm-uhf-nav-link" href="https://support.xbox.com/en-US/help/hardware-network/settings-updates/whats-new-xbox-one-system-updates" data-m='{"cN":"CatNav_Support_XboxSystemUpdates_MSXC_nav","id":"n1c5c12c8c2m1r1a1","sN":1,"aN":"c5c12c8c2m1r1a1"}'>Xbox system updates</a>
            
        </li>
                                                    
                                </ul>
                            </div>
                        </li>                        <li class="nested-menu uhf-menu-item">
                            <div class="c-uhf-menu js-nav-menu">
                                <button type="button" id="c-shellmenu_128"  aria-expanded="false" data-m='{"cN":"CatNav_My_Xbox_nonnav","id":"nn13c8c2m1r1a1","sN":13,"aN":"c8c2m1r1a1"}'>My Xbox </button>

                                <ul class="" data-class-idn="" aria-hidden="true" data-m='{"cN":"My_Xbox_cont","cT":"Container","id":"c14c8c2m1r1a1","sN":14,"aN":"c8c2m1r1a1"}'>
        <li class="js-nav-menu single-link" data-m='{"cN":"My_xbox_home_cont","cT":"Container","id":"c1c14c8c2m1r1a1","sN":1,"aN":"c14c8c2m1r1a1"}'>
            <a id="c-shellmenu_129" class="js-subm-uhf-nav-link" href="https://account.xbox.com/en-US/social?xr=shellnav" data-m='{"cN":"CatNav_My_xbox_home_nav","id":"n1c1c14c8c2m1r1a1","sN":1,"aN":"c1c14c8c2m1r1a1"}'>Home</a>
            
        </li>
        <li class="js-nav-menu single-link" data-m='{"cN":"Profile_cont","cT":"Container","id":"c2c14c8c2m1r1a1","sN":2,"aN":"c14c8c2m1r1a1"}'>
            <a id="c-shellmenu_130" class="js-subm-uhf-nav-link" href="https://account.xbox.com/en-US/Profile?xr=shellnav" data-m='{"cN":"CatNav_Profile_nav","id":"n1c2c14c8c2m1r1a1","sN":1,"aN":"c2c14c8c2m1r1a1"}'>Profile</a>
            
        </li>
                                                    
                                </ul>
                            </div>
                        </li>                        <li class="nested-menu uhf-menu-item">
                            <div class="c-uhf-menu js-nav-menu">
                                <button type="button" id="c-shellmenu_131"  aria-expanded="false" data-m='{"cN":"CatNav_Developers_nonnav","id":"nn15c8c2m1r1a1","sN":15,"aN":"c8c2m1r1a1"}'>Developers </button>

                                <ul class="" data-class-idn="" aria-hidden="true" data-m='{"cN":"Developers_cont","cT":"Container","id":"c16c8c2m1r1a1","sN":16,"aN":"c8c2m1r1a1"}'>
        <li class="js-nav-menu single-link" data-m='{"cN":"Games_cont","cT":"Container","id":"c1c16c8c2m1r1a1","sN":1,"aN":"c16c8c2m1r1a1"}'>
            <a id="c-shellmenu_132" class="js-subm-uhf-nav-link" href="https://www.xbox.com/en-US/developers?xr=shellnav" data-m='{"cN":"CatNav_Games_nav","id":"n1c1c16c8c2m1r1a1","sN":1,"aN":"c1c16c8c2m1r1a1"}'>Games</a>
            
        </li>
        <li class="js-nav-menu single-link" data-m='{"cN":"ID_Xbox_cont","cT":"Container","id":"c2c16c8c2m1r1a1","sN":2,"aN":"c16c8c2m1r1a1"}'>
            <a id="c-shellmenu_133" class="js-subm-uhf-nav-link" href="https://www.xbox.com/en-US/developers/id?xr=shellnav" data-m='{"cN":"CatNav_ID_Xbox_nav","id":"n1c2c16c8c2m1r1a1","sN":1,"aN":"c2c16c8c2m1r1a1"}'>ID@Xbox</a>
            
        </li>
        <li class="js-nav-menu single-link" data-m='{"cN":"Windows_cont","cT":"Container","id":"c3c16c8c2m1r1a1","sN":3,"aN":"c16c8c2m1r1a1"}'>
            <a id="c-shellmenu_134" class="js-subm-uhf-nav-link" href="https://dev.windows.com/games?xr=shellnav" data-m='{"cN":"CatNav_Windows_nav","id":"n1c3c16c8c2m1r1a1","sN":1,"aN":"c3c16c8c2m1r1a1"}'>Windows</a>
            
        </li>
        <li class="js-nav-menu single-link" data-m='{"cN":"Creators_Program_cont","cT":"Container","id":"c4c16c8c2m1r1a1","sN":4,"aN":"c16c8c2m1r1a1"}'>
            <a id="c-shellmenu_135" class="js-subm-uhf-nav-link" href="https://www.xbox.com/en-US/developers/creators-program?xr=shellnav" data-m='{"cN":"CatNav_Creators_Program_nav","id":"n1c4c16c8c2m1r1a1","sN":1,"aN":"c4c16c8c2m1r1a1"}'>Creators Program</a>
            
        </li>
        <li class="js-nav-menu single-link" data-m='{"cN":"Designed_for_Xbox_cont","cT":"Container","id":"c5c16c8c2m1r1a1","sN":5,"aN":"c16c8c2m1r1a1"}'>
            <a id="c-shellmenu_136" class="js-subm-uhf-nav-link" href="https://www.xbox.com/en-US/designed-for-xbox?xr=shellnav" data-m='{"cN":"CatNav_Designed_for_Xbox_nav","id":"n1c5c16c8c2m1r1a1","sN":1,"aN":"c5c16c8c2m1r1a1"}'>Designed for Xbox</a>
            
        </li>
                                                    
                                </ul>
                            </div>
                        </li>

                <li id="overflow-menu" class="overflow-menu x-hidden uhf-menu-item">
                        <div class="c-uhf-menu js-nav-menu">
        <button data-m='{"pid":"More","id":"nn17c8c2m1r1a1","sN":17,"aN":"c8c2m1r1a1"}' type="button" aria-label="More" aria-expanded="false">More</button>
        <ul id="overflow-menu-list" aria-hidden="true" class="overflow-menu-list">
        </ul>
    </div>

                </li>
                            </ul>
            
        </nav>


            <div class="c-uhfh-actions" data-m='{"cN":"Header actions_cont","cT":"Container","id":"c9c2m1r1a1","sN":9,"aN":"c2m1r1a1"}'>
                <div class="wf-menu">        <nav id="uhf-c-nav" aria-label="All Microsoft menu" data-m='{"cN":"GlobalNav_cont","cT":"Container","id":"c1c9c2m1r1a1","sN":1,"aN":"c9c2m1r1a1"}'>
            <ul class="js-paddle-items">
                <li>
                    <div class="c-uhf-menu js-nav-menu">
                        <button type="button" class="c-button-logo all-ms-nav" aria-label="All Microsoft expand to see list of Microsoft products and services" aria-expanded="false" data-m='{"cN":"GlobalNav_More_nonnav","id":"nn1c1c9c2m1r1a1","sN":1,"aN":"c1c9c2m1r1a1"}'> <span>All Microsoft</span></button>
                        <ul class="f-multi-column f-multi-column-6" aria-hidden="true" data-m='{"cN":"More_cont","cT":"Container","id":"c2c1c9c2m1r1a1","sN":2,"aN":"c1c9c2m1r1a1"}'>
                                    <li class="c-w0-contr">
            <ul class="c-w0">
        <li class="js-nav-menu single-link" data-m='{"cN":"M365_cont","cT":"Container","id":"c1c2c1c9c2m1r1a1","sN":1,"aN":"c2c1c9c2m1r1a1"}'>
            <a id="shellmenu_0" class="js-subm-uhf-nav-link" href="https://www.microsoft.com/microsoft-365" data-m='{"cN":"W0Nav_M365_nav","id":"n1c1c2c1c9c2m1r1a1","sN":1,"aN":"c1c2c1c9c2m1r1a1"}'>Microsoft 365</a>
            
        </li>
        <li class="js-nav-menu single-link" data-m='{"cN":"Office_cont","cT":"Container","id":"c2c2c1c9c2m1r1a1","sN":2,"aN":"c2c1c9c2m1r1a1"}'>
            <a id="shellmenu_1" class="js-subm-uhf-nav-link" href="https://www.microsoft.com/en-us/microsoft-365/microsoft-office" data-m='{"cN":"W0Nav_Office_nav","id":"n1c2c2c1c9c2m1r1a1","sN":1,"aN":"c2c2c1c9c2m1r1a1"}'>Office</a>
            
        </li>
        <li class="js-nav-menu single-link" data-m='{"cN":"Windows_cont","cT":"Container","id":"c3c2c1c9c2m1r1a1","sN":3,"aN":"c2c1c9c2m1r1a1"}'>
            <a id="shellmenu_2" class="js-subm-uhf-nav-link" href="https://www.microsoft.com/en-us/windows/" data-m='{"cN":"W0Nav_Windows_nav","id":"n1c3c2c1c9c2m1r1a1","sN":1,"aN":"c3c2c1c9c2m1r1a1"}'>Windows</a>
            
        </li>
        <li class="js-nav-menu single-link" data-m='{"cN":"Surface_cont","cT":"Container","id":"c4c2c1c9c2m1r1a1","sN":4,"aN":"c2c1c9c2m1r1a1"}'>
            <a id="shellmenu_3" class="js-subm-uhf-nav-link" href="https://www.microsoft.com/surface" data-m='{"cN":"W0Nav_Surface_nav","id":"n1c4c2c1c9c2m1r1a1","sN":1,"aN":"c4c2c1c9c2m1r1a1"}'>Surface</a>
            
        </li>
        <li class="js-nav-menu single-link" data-m='{"cN":"Xbox_cont","cT":"Container","id":"c5c2c1c9c2m1r1a1","sN":5,"aN":"c2c1c9c2m1r1a1"}'>
            <a id="shellmenu_4" class="js-subm-uhf-nav-link" href="https://www.xbox.com/" data-m='{"cN":"W0Nav_Xbox_nav","id":"n1c5c2c1c9c2m1r1a1","sN":1,"aN":"c5c2c1c9c2m1r1a1"}'>Xbox</a>
            
        </li>
        <li class="js-nav-menu single-link" data-m='{"cN":"Deals_cont","cT":"Container","id":"c6c2c1c9c2m1r1a1","sN":6,"aN":"c2c1c9c2m1r1a1"}'>
            <a id="shellmenu_5" class="js-subm-uhf-nav-link" href="https://www.microsoft.com/en-us/store/b/sale?icid=gm_nav_L0_salepage" data-m='{"cN":"W0Nav_Deals_nav","id":"n1c6c2c1c9c2m1r1a1","sN":1,"aN":"c6c2c1c9c2m1r1a1"}'>Deals</a>
            
        </li>
        <li class="js-nav-menu single-link" data-m='{"cN":"Support_cont","cT":"Container","id":"c7c2c1c9c2m1r1a1","sN":7,"aN":"c2c1c9c2m1r1a1"}'>
            <a id="l1_support" class="js-subm-uhf-nav-link" href="https://support.microsoft.com/en-us" data-m='{"cN":"W0Nav_Support_nav","id":"n1c7c2c1c9c2m1r1a1","sN":1,"aN":"c7c2c1c9c2m1r1a1"}'>Support</a>
            
        </li>
            </ul>
        </li>

<li class="f-sub-menu js-nav-menu nested-menu" data-m='{"cT":"Container","id":"c8c2c1c9c2m1r1a1","sN":8,"aN":"c2c1c9c2m1r1a1"}'>

    <span id="uhf-navspn-shellmenu_8-span" style="display:none"   f-multi-parent="true" aria-expanded="false" data-m='{"id":"nn1c8c2c1c9c2m1r1a1","sN":1,"aN":"c8c2c1c9c2m1r1a1"}'>Software</span>
    <button id="uhf-navbtn-shellmenu_8-button" type="button"   f-multi-parent="true" aria-expanded="false" data-m='{"id":"nn2c8c2c1c9c2m1r1a1","sN":2,"aN":"c8c2c1c9c2m1r1a1"}'>Software</button>
    <ul aria-hidden="true" aria-labelledby="uhf-navspn-shellmenu_8-span">
        <li class="js-nav-menu single-link" data-m='{"cN":"More_Software_WindowsApps_cont","cT":"Container","id":"c3c8c2c1c9c2m1r1a1","sN":3,"aN":"c8c2c1c9c2m1r1a1"}'>
            <a id="shellmenu_9" class="js-subm-uhf-nav-link" href="https://www.microsoft.com/en-us/store/apps/windows?icid=CNavAppsWindowsApps" data-m='{"cN":"GlobalNav_More_Software_WindowsApps_nav","id":"n1c3c8c2c1c9c2m1r1a1","sN":1,"aN":"c3c8c2c1c9c2m1r1a1"}'>Windows Apps</a>
            
        </li>
        <li class="js-nav-menu single-link" data-m='{"cN":"More_Software_OneDrive_cont","cT":"Container","id":"c4c8c2c1c9c2m1r1a1","sN":4,"aN":"c8c2c1c9c2m1r1a1"}'>
            <a id="shellmenu_10" class="js-subm-uhf-nav-link" href="https://onedrive.live.com/about/en-us/" data-m='{"cN":"GlobalNav_More_Software_OneDrive_nav","id":"n1c4c8c2c1c9c2m1r1a1","sN":1,"aN":"c4c8c2c1c9c2m1r1a1"}'>OneDrive</a>
            
        </li>
        <li class="js-nav-menu single-link" data-m='{"cN":"More_Software_Outlook_cont","cT":"Container","id":"c5c8c2c1c9c2m1r1a1","sN":5,"aN":"c8c2c1c9c2m1r1a1"}'>
            <a id="shellmenu_11" class="js-subm-uhf-nav-link" href="https://outlook.live.com/owa/" data-m='{"cN":"GlobalNav_More_Software_Outlook_nav","id":"n1c5c8c2c1c9c2m1r1a1","sN":1,"aN":"c5c8c2c1c9c2m1r1a1"}'>Outlook</a>
            
        </li>
        <li class="js-nav-menu single-link" data-m='{"cN":"More_Software_Skype_cont","cT":"Container","id":"c6c8c2c1c9c2m1r1a1","sN":6,"aN":"c8c2c1c9c2m1r1a1"}'>
            <a id="shellmenu_12" class="js-subm-uhf-nav-link" href="https://www.skype.com/en/" data-m='{"cN":"GlobalNav_More_Software_Skype_nav","id":"n1c6c8c2c1c9c2m1r1a1","sN":1,"aN":"c6c8c2c1c9c2m1r1a1"}'>Skype</a>
            
        </li>
        <li class="js-nav-menu single-link" data-m='{"cN":"More_Software_OneNote_cont","cT":"Container","id":"c7c8c2c1c9c2m1r1a1","sN":7,"aN":"c8c2c1c9c2m1r1a1"}'>
            <a id="shellmenu_13" class="js-subm-uhf-nav-link" href="https://www.onenote.com/" data-m='{"cN":"GlobalNav_More_Software_OneNote_nav","id":"n1c7c8c2c1c9c2m1r1a1","sN":1,"aN":"c7c8c2c1c9c2m1r1a1"}'>OneNote</a>
            
        </li>
        <li class="js-nav-menu single-link" data-m='{"cN":"More_Software_Microsoft Teams_cont","cT":"Container","id":"c8c8c2c1c9c2m1r1a1","sN":8,"aN":"c8c2c1c9c2m1r1a1"}'>
            <a id="shellmenu_14" class="js-subm-uhf-nav-link" href="https://www.microsoft.com/EN-US/microsoft-teams/group-chat-software" data-m='{"cN":"GlobalNav_More_Software_Microsoft Teams_nav","id":"n1c8c8c2c1c9c2m1r1a1","sN":1,"aN":"c8c8c2c1c9c2m1r1a1"}'>Microsoft Teams</a>
            
        </li>
        <li class="js-nav-menu single-link" data-m='{"cN":"microsoft edge_cont","cT":"Container","id":"c9c8c2c1c9c2m1r1a1","sN":9,"aN":"c8c2c1c9c2m1r1a1"}'>
            <a id="shellmenu_15" class="js-subm-uhf-nav-link" href="https://www.microsoft.com/edge" data-m='{"cN":"GlobalNav_microsoft edge_nav","id":"n1c9c8c2c1c9c2m1r1a1","sN":1,"aN":"c9c8c2c1c9c2m1r1a1"}'>Microsoft Edge</a>
            
        </li>
    </ul>
    
</li>
<li class="f-sub-menu js-nav-menu nested-menu" data-m='{"cN":"PCsAndDevices_cont","cT":"Container","id":"c9c2c1c9c2m1r1a1","sN":9,"aN":"c2c1c9c2m1r1a1"}'>

    <span id="uhf-navspn-shellmenu_16-span" style="display:none"   f-multi-parent="true" aria-expanded="false" data-m='{"cN":"GlobalNav_PCsAndDevices_nonnav","id":"nn1c9c2c1c9c2m1r1a1","sN":1,"aN":"c9c2c1c9c2m1r1a1"}'>PCs &amp; Devices  </span>
    <button id="uhf-navbtn-shellmenu_16-button" type="button"   f-multi-parent="true" aria-expanded="false" data-m='{"cN":"GlobalNav_PCsAndDevices_nonnav","id":"nn2c9c2c1c9c2m1r1a1","sN":2,"aN":"c9c2c1c9c2m1r1a1"}'>PCs &amp; Devices  </button>
    <ul aria-hidden="true" aria-labelledby="uhf-navspn-shellmenu_16-span">
        <li class="js-nav-menu single-link" data-m='{"cN":"More_PCsAndDevices_PCsAndTablets_cont","cT":"Container","id":"c3c9c2c1c9c2m1r1a1","sN":3,"aN":"c9c2c1c9c2m1r1a1"}'>
            <a id="shellmenu_17" class="js-subm-uhf-nav-link" href="https://www.microsoft.com/en-us/store/b/pc?icid=CNavDevicesPC" data-m='{"cN":"GlobalNav_More_PCsAndDevices_PCsAndTablets_nav","id":"n1c3c9c2c1c9c2m1r1a1","sN":1,"aN":"c3c9c2c1c9c2m1r1a1"}'>Computers</a>
            
        </li>
        <li class="js-nav-menu single-link" data-m='{"cN":"More_PCAndDevices_ShopXbox_cont","cT":"Container","id":"c4c9c2c1c9c2m1r1a1","sN":4,"aN":"c9c2c1c9c2m1r1a1"}'>
            <a id="shellmenu_18" class="js-subm-uhf-nav-link" href="https://www.microsoft.com/en-us/store/b/xbox?icid=CNavDevicesXbox" data-m='{"cN":"GlobalNav_More_PCAndDevices_ShopXbox_nav","id":"n1c4c9c2c1c9c2m1r1a1","sN":1,"aN":"c4c9c2c1c9c2m1r1a1"}'>Shop Xbox</a>
            
        </li>
        <li class="js-nav-menu single-link" data-m='{"cN":"More_PCAndDevices_Accessories_cont","cT":"Container","id":"c5c9c2c1c9c2m1r1a1","sN":5,"aN":"c9c2c1c9c2m1r1a1"}'>
            <a id="shellmenu_19" class="js-subm-uhf-nav-link" href="https://www.microsoft.com/en-us/store/b/accessories?icid=CNavDevicesAccessories" data-m='{"cN":"GlobalNav_More_PCAndDevices_Accessories_nav","id":"n1c5c9c2c1c9c2m1r1a1","sN":1,"aN":"c5c9c2c1c9c2m1r1a1"}'>Accessories</a>
            
        </li>
        <li class="js-nav-menu single-link" data-m='{"cN":"More_PCsAndDevices_VMAndMixedReality_cont","cT":"Container","id":"c6c9c2c1c9c2m1r1a1","sN":6,"aN":"c9c2c1c9c2m1r1a1"}'>
            <a id="shellmenu_20" class="js-subm-uhf-nav-link" href="https://www.microsoft.com/en-us/store/b/virtualreality?icid=CNavVirtualReality" data-m='{"cN":"GlobalNav_More_PCsAndDevices_VMAndMixedReality_nav","id":"n1c6c9c2c1c9c2m1r1a1","sN":1,"aN":"c6c9c2c1c9c2m1r1a1"}'>VR &amp; mixed reality</a>
            
        </li>
        <li class="js-nav-menu single-link" data-m='{"cN":"More_PCAndDevices_Phone_cont","cT":"Container","id":"c7c9c2c1c9c2m1r1a1","sN":7,"aN":"c9c2c1c9c2m1r1a1"}'>
            <a id="shellmenu_21" class="js-subm-uhf-nav-link" href="https://www.microsoft.com/en-us/store/b/mobile?icid=CNavDevicesMobile" data-m='{"cN":"GlobalNav_More_PCAndDevices_Phone_nav","id":"n1c7c9c2c1c9c2m1r1a1","sN":1,"aN":"c7c9c2c1c9c2m1r1a1"}'>Phones</a>
            
        </li>
    </ul>
    
</li>
<li class="f-sub-menu js-nav-menu nested-menu" data-m='{"cT":"Container","id":"c10c2c1c9c2m1r1a1","sN":10,"aN":"c2c1c9c2m1r1a1"}'>

    <span id="uhf-navspn-shellmenu_22-span" style="display:none"   f-multi-parent="true" aria-expanded="false" data-m='{"id":"nn1c10c2c1c9c2m1r1a1","sN":1,"aN":"c10c2c1c9c2m1r1a1"}'>Entertainment</span>
    <button id="uhf-navbtn-shellmenu_22-button" type="button"   f-multi-parent="true" aria-expanded="false" data-m='{"id":"nn2c10c2c1c9c2m1r1a1","sN":2,"aN":"c10c2c1c9c2m1r1a1"}'>Entertainment</button>
    <ul aria-hidden="true" aria-labelledby="uhf-navspn-shellmenu_22-span">
        <li class="js-nav-menu single-link" data-m='{"cN":"Products_DevicesAndXbox_XboxGamePassUltimate_cont","cT":"Container","id":"c3c10c2c1c9c2m1r1a1","sN":3,"aN":"c10c2c1c9c2m1r1a1"}'>
            <a id="shellmenu_23" class="js-subm-uhf-nav-link" href="https://www.xbox.com/en-us/games/store/xbox-game-pass-ultimate/cfq7ttc0khs0?icid=CNavAllXboxGamePassUltimate" data-m='{"cN":"GlobalNav_Products_DevicesAndXbox_XboxGamePassUltimate_nav","id":"n1c3c10c2c1c9c2m1r1a1","sN":1,"aN":"c3c10c2c1c9c2m1r1a1"}'>Xbox Game Pass Ultimate</a>
            
        </li>
        <li class="js-nav-menu single-link" data-m='{"cN":"Products_DevicesAndXbox_PC_Game_Pass_cont","cT":"Container","id":"c4c10c2c1c9c2m1r1a1","sN":4,"aN":"c10c2c1c9c2m1r1a1"}'>
            <a id="shellmenu_24" class="js-subm-uhf-nav-link" href="https://www.xbox.com/en-us/games/store/pc-game-pass/cfq7ttc0kgq8?icid=CNavAllPCGamePass" data-m='{"cN":"GlobalNav_Products_DevicesAndXbox_PC_Game_Pass_nav","id":"n1c4c10c2c1c9c2m1r1a1","sN":1,"aN":"c4c10c2c1c9c2m1r1a1"}'>PC Game Pass</a>
            
        </li>
        <li class="js-nav-menu single-link" data-m='{"cN":"Products_DevicesAndXbox_XboxAndGames_cont","cT":"Container","id":"c5c10c2c1c9c2m1r1a1","sN":5,"aN":"c10c2c1c9c2m1r1a1"}'>
            <a id="shellmenu_25" class="js-subm-uhf-nav-link" href="https://www.microsoft.com/en-us/store/b/xboxgames?icid=CNavGamesXboxGames" data-m='{"cN":"GlobalNav_Products_DevicesAndXbox_XboxAndGames_nav","id":"n1c5c10c2c1c9c2m1r1a1","sN":1,"aN":"c5c10c2c1c9c2m1r1a1"}'>Xbox games</a>
            
        </li>
        <li class="js-nav-menu single-link" data-m='{"cN":"Entertainment_PCGames_cont","cT":"Container","id":"c6c10c2c1c9c2m1r1a1","sN":6,"aN":"c10c2c1c9c2m1r1a1"}'>
            <a id="shellmenu_26" class="js-subm-uhf-nav-link" href="https://www.microsoft.com/en-us/store/games/windows?icid=CNavGamesWindowsGames" data-m='{"cN":"GlobalNav_Entertainment_PCGames_nav","id":"n1c6c10c2c1c9c2m1r1a1","sN":1,"aN":"c6c10c2c1c9c2m1r1a1"}'>PC games</a>
            
        </li>
        <li class="js-nav-menu single-link" data-m='{"cN":"More_Entertainment_WindowsDigitalGames_cont","cT":"Container","id":"c7c10c2c1c9c2m1r1a1","sN":7,"aN":"c10c2c1c9c2m1r1a1"}'>
            <a id="shellmenu_27" class="js-subm-uhf-nav-link" href="https://www.microsoft.com/en-us/store/games/windows?icid=TopNavWindowsGames" data-m='{"cN":"GlobalNav_More_Entertainment_WindowsDigitalGames_nav","id":"n1c7c10c2c1c9c2m1r1a1","sN":1,"aN":"c7c10c2c1c9c2m1r1a1"}'>Windows digital games</a>
            
        </li>
        <li class="js-nav-menu single-link" data-m='{"cN":"More_Entertainment_MoviesAndTV_cont","cT":"Container","id":"c8c10c2c1c9c2m1r1a1","sN":8,"aN":"c10c2c1c9c2m1r1a1"}'>
            <a id="shellmenu_28" class="js-subm-uhf-nav-link" href="https://www.microsoft.com/en-us/store/movies-and-tv?icid=TopNavMoviesTv" data-m='{"cN":"GlobalNav_More_Entertainment_MoviesAndTV_nav","id":"n1c8c10c2c1c9c2m1r1a1","sN":1,"aN":"c8c10c2c1c9c2m1r1a1"}'>Movies &amp; TV</a>
            
        </li>
    </ul>
    
</li>
<li class="f-sub-menu js-nav-menu nested-menu" data-m='{"cT":"Container","id":"c11c2c1c9c2m1r1a1","sN":11,"aN":"c2c1c9c2m1r1a1"}'>

    <span id="uhf-navspn-shellmenu_29-span" style="display:none"   f-multi-parent="true" aria-expanded="false" data-m='{"id":"nn1c11c2c1c9c2m1r1a1","sN":1,"aN":"c11c2c1c9c2m1r1a1"}'>Business</span>
    <button id="uhf-navbtn-shellmenu_29-button" type="button"   f-multi-parent="true" aria-expanded="false" data-m='{"id":"nn2c11c2c1c9c2m1r1a1","sN":2,"aN":"c11c2c1c9c2m1r1a1"}'>Business</button>
    <ul aria-hidden="true" aria-labelledby="uhf-navspn-shellmenu_29-span">
        <li class="js-nav-menu single-link" data-m='{"cN":"More_Business_Microsoft_Cloud_cont","cT":"Container","id":"c3c11c2c1c9c2m1r1a1","sN":3,"aN":"c11c2c1c9c2m1r1a1"}'>
            <a id="shellmenu_30" class="js-subm-uhf-nav-link" href="https://www.microsoft.com/en-us/microsoft-cloud" data-m='{"cN":"GlobalNav_More_Business_Microsoft_Cloud_nav","id":"n1c3c11c2c1c9c2m1r1a1","sN":1,"aN":"c3c11c2c1c9c2m1r1a1"}'>Microsoft Cloud</a>
            
        </li>
        <li class="js-nav-menu single-link" data-m='{"cN":"More_Business_Microsoft Security_cont","cT":"Container","id":"c4c11c2c1c9c2m1r1a1","sN":4,"aN":"c11c2c1c9c2m1r1a1"}'>
            <a id="shellmenu_31" class="js-subm-uhf-nav-link" href="https://www.microsoft.com/en-us/security" data-m='{"cN":"GlobalNav_More_Business_Microsoft Security_nav","id":"n1c4c11c2c1c9c2m1r1a1","sN":1,"aN":"c4c11c2c1c9c2m1r1a1"}'>Microsoft Security</a>
            
        </li>
        <li class="js-nav-menu single-link" data-m='{"cN":"More_Business_MicrosoftDynamics365_cont","cT":"Container","id":"c5c11c2c1c9c2m1r1a1","sN":5,"aN":"c11c2c1c9c2m1r1a1"}'>
            <a id="shellmenu_32" class="js-subm-uhf-nav-link" href="https://dynamics.microsoft.com/en-us/" data-m='{"cN":"GlobalNav_More_Business_MicrosoftDynamics365_nav","id":"n1c5c11c2c1c9c2m1r1a1","sN":1,"aN":"c5c11c2c1c9c2m1r1a1"}'>Dynamics 365</a>
            
        </li>
        <li class="js-nav-menu single-link" data-m='{"cN":"More_Business_Microsoft365forbusiness_cont","cT":"Container","id":"c6c11c2c1c9c2m1r1a1","sN":6,"aN":"c11c2c1c9c2m1r1a1"}'>
            <a id="shellmenu_33" class="js-subm-uhf-nav-link" href="https://www.microsoft.com/en-us/microsoft-365/business" data-m='{"cN":"GlobalNav_More_Business_Microsoft365forbusiness_nav","id":"n1c6c11c2c1c9c2m1r1a1","sN":1,"aN":"c6c11c2c1c9c2m1r1a1"}'>Microsoft 365 for business</a>
            
        </li>
        <li class="js-nav-menu single-link" data-m='{"cN":"More_Business_MicrosoftPowerPlatform_cont","cT":"Container","id":"c7c11c2c1c9c2m1r1a1","sN":7,"aN":"c11c2c1c9c2m1r1a1"}'>
            <a id="shellmenu_34" class="js-subm-uhf-nav-link" href="https://powerplatform.microsoft.com/en-us/" data-m='{"cN":"GlobalNav_More_Business_MicrosoftPowerPlatform_nav","id":"n1c7c11c2c1c9c2m1r1a1","sN":1,"aN":"c7c11c2c1c9c2m1r1a1"}'>Microsoft Power Platform</a>
            
        </li>
        <li class="js-nav-menu single-link" data-m='{"cN":"More_Business_Windows365_cont","cT":"Container","id":"c8c11c2c1c9c2m1r1a1","sN":8,"aN":"c11c2c1c9c2m1r1a1"}'>
            <a id="shellmenu_35" class="js-subm-uhf-nav-link" href="https://www.microsoft.com/en-us/windows-365" data-m='{"cN":"GlobalNav_More_Business_Windows365_nav","id":"n1c8c11c2c1c9c2m1r1a1","sN":1,"aN":"c8c11c2c1c9c2m1r1a1"}'>Windows 365</a>
            
        </li>
        <li class="js-nav-menu single-link" data-m='{"cN":"More_Business_MicrosoftIndustry_cont","cT":"Container","id":"c9c11c2c1c9c2m1r1a1","sN":9,"aN":"c11c2c1c9c2m1r1a1"}'>
            <a id="shellmenu_36" class="js-subm-uhf-nav-link" href="https://www.microsoft.com/en-us/industry" data-m='{"cN":"GlobalNav_More_Business_MicrosoftIndustry_nav","id":"n1c9c11c2c1c9c2m1r1a1","sN":1,"aN":"c9c11c2c1c9c2m1r1a1"}'>Microsoft Industry</a>
            
        </li>
        <li class="js-nav-menu single-link" data-m='{"cN":"More_Business_SmallBusiness_cont","cT":"Container","id":"c10c11c2c1c9c2m1r1a1","sN":10,"aN":"c11c2c1c9c2m1r1a1"}'>
            <a id="shellmenu_37" class="js-subm-uhf-nav-link" href="https://www.microsoft.com/en-us/store/b/business?icid=CNavBusinessStore" data-m='{"cN":"GlobalNav_More_Business_SmallBusiness_nav","id":"n1c10c11c2c1c9c2m1r1a1","sN":1,"aN":"c10c11c2c1c9c2m1r1a1"}'>Small Business</a>
            
        </li>
    </ul>
    
</li>
<li class="f-sub-menu js-nav-menu nested-menu" data-m='{"cT":"Container","id":"c12c2c1c9c2m1r1a1","sN":12,"aN":"c2c1c9c2m1r1a1"}'>

    <span id="uhf-navspn-shellmenu_38-span" style="display:none"   f-multi-parent="true" aria-expanded="false" data-m='{"id":"nn1c12c2c1c9c2m1r1a1","sN":1,"aN":"c12c2c1c9c2m1r1a1"}'>Developer &amp; IT  </span>
    <button id="uhf-navbtn-shellmenu_38-button" type="button"   f-multi-parent="true" aria-expanded="false" data-m='{"id":"nn2c12c2c1c9c2m1r1a1","sN":2,"aN":"c12c2c1c9c2m1r1a1"}'>Developer &amp; IT  </button>
    <ul aria-hidden="true" aria-labelledby="uhf-navspn-shellmenu_38-span">
        <li class="js-nav-menu single-link" data-m='{"cN":"More_Business_MicrosoftAzure_cont","cT":"Container","id":"c3c12c2c1c9c2m1r1a1","sN":3,"aN":"c12c2c1c9c2m1r1a1"}'>
            <a id="shellmenu_39" class="js-subm-uhf-nav-link" href="https://azure.microsoft.com/en-us/" data-m='{"cN":"GlobalNav_More_Business_MicrosoftAzure_nav","id":"n1c3c12c2c1c9c2m1r1a1","sN":1,"aN":"c3c12c2c1c9c2m1r1a1"}'>Azure</a>
            
        </li>
        <li class="js-nav-menu single-link" data-m='{"cN":"More_DeveloperAndIT_DeveloperCenter_cont","cT":"Container","id":"c4c12c2c1c9c2m1r1a1","sN":4,"aN":"c12c2c1c9c2m1r1a1"}'>
            <a id="shellmenu_40" class="js-subm-uhf-nav-link" href="https://developer.microsoft.com/en-us/" data-m='{"cN":"GlobalNav_More_DeveloperAndIT_DeveloperCenter_nav","id":"n1c4c12c2c1c9c2m1r1a1","sN":1,"aN":"c4c12c2c1c9c2m1r1a1"}'>Developer Center</a>
            
        </li>
        <li class="js-nav-menu single-link" data-m='{"cN":"More_DeveloperAndIT_Documentation_cont","cT":"Container","id":"c5c12c2c1c9c2m1r1a1","sN":5,"aN":"c12c2c1c9c2m1r1a1"}'>
            <a id="shellmenu_41" class="js-subm-uhf-nav-link" href="https://docs.microsoft.com/en-us/" data-m='{"cN":"GlobalNav_More_DeveloperAndIT_Documentation_nav","id":"n1c5c12c2c1c9c2m1r1a1","sN":1,"aN":"c5c12c2c1c9c2m1r1a1"}'>Documentation</a>
            
        </li>
        <li class="js-nav-menu single-link" data-m='{"cN":"More_DeveloperAndIT_MicrosoftLearn_cont","cT":"Container","id":"c6c12c2c1c9c2m1r1a1","sN":6,"aN":"c12c2c1c9c2m1r1a1"}'>
            <a id="shellmenu_42" class="js-subm-uhf-nav-link" href="https://docs.microsoft.com/en-us/learn/" data-m='{"cN":"GlobalNav_More_DeveloperAndIT_MicrosoftLearn_nav","id":"n1c6c12c2c1c9c2m1r1a1","sN":1,"aN":"c6c12c2c1c9c2m1r1a1"}'>Microsoft Learn</a>
            
        </li>
        <li class="js-nav-menu single-link" data-m='{"cN":"More_DeveloperAndIT_MicrosoftTechCommunity_cont","cT":"Container","id":"c7c12c2c1c9c2m1r1a1","sN":7,"aN":"c12c2c1c9c2m1r1a1"}'>
            <a id="shellmenu_43" class="js-subm-uhf-nav-link" href="https://techcommunity.microsoft.com/" data-m='{"cN":"GlobalNav_More_DeveloperAndIT_MicrosoftTechCommunity_nav","id":"n1c7c12c2c1c9c2m1r1a1","sN":1,"aN":"c7c12c2c1c9c2m1r1a1"}'>Microsoft Tech Community</a>
            
        </li>
        <li class="js-nav-menu single-link" data-m='{"cN":"More_DeveloperAndIT_AzureMarketplace_cont","cT":"Container","id":"c8c12c2c1c9c2m1r1a1","sN":8,"aN":"c12c2c1c9c2m1r1a1"}'>
            <a id="shellmenu_44" class="js-subm-uhf-nav-link" href="https://azuremarketplace.microsoft.com/en-us/" data-m='{"cN":"GlobalNav_More_DeveloperAndIT_AzureMarketplace_nav","id":"n1c8c12c2c1c9c2m1r1a1","sN":1,"aN":"c8c12c2c1c9c2m1r1a1"}'>Azure Marketplace</a>
            
        </li>
        <li class="js-nav-menu single-link" data-m='{"cN":"More_DeveloperAndIT_AppSource_cont","cT":"Container","id":"c9c12c2c1c9c2m1r1a1","sN":9,"aN":"c12c2c1c9c2m1r1a1"}'>
            <a id="shellmenu_45" class="js-subm-uhf-nav-link" href="https://appsource.microsoft.com/en-us/" data-m='{"cN":"GlobalNav_More_DeveloperAndIT_AppSource_nav","id":"n1c9c12c2c1c9c2m1r1a1","sN":1,"aN":"c9c12c2c1c9c2m1r1a1"}'>AppSource</a>
            
        </li>
        <li class="js-nav-menu single-link" data-m='{"cN":"More_DevelopersAndIT_VisualStudio_cont","cT":"Container","id":"c10c12c2c1c9c2m1r1a1","sN":10,"aN":"c12c2c1c9c2m1r1a1"}'>
            <a id="shellmenu_46" class="js-subm-uhf-nav-link" href="https://visualstudio.microsoft.com/" data-m='{"cN":"GlobalNav_More_DevelopersAndIT_VisualStudio_nav","id":"n1c10c12c2c1c9c2m1r1a1","sN":1,"aN":"c10c12c2c1c9c2m1r1a1"}'>Visual Studio</a>
            
        </li>
    </ul>
    
</li>
<li class="f-sub-menu js-nav-menu nested-menu" data-m='{"cT":"Container","id":"c13c2c1c9c2m1r1a1","sN":13,"aN":"c2c1c9c2m1r1a1"}'>

    <span id="uhf-navspn-shellmenu_47-span" style="display:none"   f-multi-parent="true" aria-expanded="false" data-m='{"id":"nn1c13c2c1c9c2m1r1a1","sN":1,"aN":"c13c2c1c9c2m1r1a1"}'>Other</span>
    <button id="uhf-navbtn-shellmenu_47-button" type="button"   f-multi-parent="true" aria-expanded="false" data-m='{"id":"nn2c13c2c1c9c2m1r1a1","sN":2,"aN":"c13c2c1c9c2m1r1a1"}'>Other</button>
    <ul aria-hidden="true" aria-labelledby="uhf-navspn-shellmenu_47-span">
        <li class="js-nav-menu single-link" data-m='{"cN":"More_Other_Microsoft Rewards_cont","cT":"Container","id":"c3c13c2c1c9c2m1r1a1","sN":3,"aN":"c13c2c1c9c2m1r1a1"}'>
            <a id="shellmenu_48" class="js-subm-uhf-nav-link" href="https://www.microsoft.com/rewards" data-m='{"cN":"GlobalNav_More_Other_Microsoft Rewards_nav","id":"n1c3c13c2c1c9c2m1r1a1","sN":1,"aN":"c3c13c2c1c9c2m1r1a1"}'>Microsoft Rewards </a>
            
        </li>
        <li class="js-nav-menu single-link" data-m='{"cN":"Products_SoftwareAndServices_FreeDownloadsAndSecurity_cont","cT":"Container","id":"c4c13c2c1c9c2m1r1a1","sN":4,"aN":"c13c2c1c9c2m1r1a1"}'>
            <a id="shellmenu_49" class="js-subm-uhf-nav-link" href="https://www.microsoft.com/en-us/download/default.aspx" data-m='{"cN":"GlobalNav_Products_SoftwareAndServices_FreeDownloadsAndSecurity_nav","id":"n1c4c13c2c1c9c2m1r1a1","sN":1,"aN":"c4c13c2c1c9c2m1r1a1"}'>Free downloads &amp; security</a>
            
        </li>
        <li class="js-nav-menu single-link" data-m='{"cN":"Products_ForStudentsAndEducators_Education_cont","cT":"Container","id":"c5c13c2c1c9c2m1r1a1","sN":5,"aN":"c13c2c1c9c2m1r1a1"}'>
            <a id="shellmenu_50" class="js-subm-uhf-nav-link" href="https://www.microsoft.com/en-us/education?icid=CNavMSCOML0_Studentsandeducation" data-m='{"cN":"GlobalNav_Products_ForStudentsAndEducators_Education_nav","id":"n1c5c13c2c1c9c2m1r1a1","sN":1,"aN":"c5c13c2c1c9c2m1r1a1"}'>Education</a>
            
        </li>
        <li class="js-nav-menu single-link" data-m='{"cN":"More_Other_Store_Locations_cont","cT":"Container","id":"c6c13c2c1c9c2m1r1a1","sN":6,"aN":"c13c2c1c9c2m1r1a1"}'>
            <a id="shellmenu_51" class="js-subm-uhf-nav-link" href="https://www.microsoft.com/en-us/store/workshops-training-and-events?icid=vl_uf_932020" data-m='{"cN":"GlobalNav_More_Other_Store_Locations_nav","id":"n1c6c13c2c1c9c2m1r1a1","sN":1,"aN":"c6c13c2c1c9c2m1r1a1"}'>Virtual workshops and training</a>
            
        </li>
        <li class="js-nav-menu single-link" data-m='{"cN":"Store_More_GiftCards_cont","cT":"Container","id":"c7c13c2c1c9c2m1r1a1","sN":7,"aN":"c13c2c1c9c2m1r1a1"}'>
            <a id="shellmenu_52" class="js-subm-uhf-nav-link" href="https://www.microsoft.com/en-us/store/b/gift-cards" data-m='{"cN":"GlobalNav_Store_More_GiftCards_nav","id":"n1c7c13c2c1c9c2m1r1a1","sN":1,"aN":"c7c13c2c1c9c2m1r1a1"}'>Gift cards</a>
            
        </li>
        <li class="js-nav-menu single-link" data-m='{"cN":"More_Other_Gift Ideas_cont","cT":"Container","id":"c8c13c2c1c9c2m1r1a1","sN":8,"aN":"c13c2c1c9c2m1r1a1"}'>
            <a id="shellmenu_53" class="js-subm-uhf-nav-link" href="https://www.microsoft.com/en-us/store/b/holiday-gift-guide" data-m='{"cN":"GlobalNav_More_Other_Gift Ideas_nav","id":"n1c8c13c2c1c9c2m1r1a1","sN":1,"aN":"c8c13c2c1c9c2m1r1a1"}'>Gift Ideas</a>
            
        </li>
        <li class="js-nav-menu single-link" data-m='{"cN":"Other_Licensing_cont","cT":"Container","id":"c9c13c2c1c9c2m1r1a1","sN":9,"aN":"c13c2c1c9c2m1r1a1"}'>
            <a id="Licensing" class="js-subm-uhf-nav-link" href="https://www.microsoft.com/licensing/" data-m='{"cN":"GlobalNav_Other_Licensing_nav","id":"n1c9c13c2c1c9c2m1r1a1","sN":1,"aN":"c9c13c2c1c9c2m1r1a1"}'>Licensing</a>
            
        </li>
        <li class="js-nav-menu single-link" data-m='{"cN":"More_Microsoft_Experience_Center_cont","cT":"Container","id":"c10c13c2c1c9c2m1r1a1","sN":10,"aN":"c13c2c1c9c2m1r1a1"}'>
            <a id="shellmenu_55" class="js-subm-uhf-nav-link" href="https://www.microsoft.com/en-us/store/locations/ny/new-york/fifth-avenue-/store-1087?ICID=uhf_h_mec" data-m='{"cN":"GlobalNav_More_Microsoft_Experience_Center_nav","id":"n1c10c13c2c1c9c2m1r1a1","sN":1,"aN":"c10c13c2c1c9c2m1r1a1"}'>Microsoft Experience Center</a>
            
        </li>
    </ul>
    
</li>
                                                            <li class="f-multi-column-info">
                                    <a data-m='{"id":"n14c2c1c9c2m1r1a1","sN":14,"aN":"c2c1c9c2m1r1a1"}' href="https://www.microsoft.com/en-us/sitemap.aspx" aria-label="" class="c-glyph">View Sitemap</a>
                                </li>
                            
                        </ul>
                    </div>
                </li>
            </ul>
        </nav>
</div>
                            <form class="c-search" autocomplete="off" id="searchForm" name="searchForm" role="search" action="https://www.xbox.com/en-us/Search" method="GET" data-seAutoSuggest='{"queryParams":{"market":"en-us","clientId":"7F27B536-CF6B-4C65-8638-A0F8CBDFCA65","sources":"Microsoft-Terms,Iris-Products,DCatAll-Products","filter":"+ClientType:StoreWeb","counts":"5,1,5"},"familyNames":{"Apps":"App","Books":"Book","Bundles":"Bundle","Devices":"Device","Fees":"Fee","Games":"Game","MusicAlbums":"Album","MusicTracks":"Song","MusicVideos":"Video","MusicArtists":"Artist","OperatingSystem":"Operating System","Software":"Software","Movies":"Movie","TV":"TV","CSV":"Gift Card","VideoActor":"Actor"}}' data-seautosuggestapi="https://www.microsoft.com/msstoreapiprod/api/autosuggest" data-m='{"cN":"GlobalNav_Search_cont","cT":"Container","id":"c3c1c9c2m1r1a1","sN":3,"aN":"c1c9c2m1r1a1"}' aria-expanded="false">
                                <input  id="cli_shellHeaderSearchInput" aria-label="Search Expanded" aria-autocomplete="list" aria-expanded="false" aria-controls="universal-header-search-auto-suggest-transparent" aria-owns="universal-header-search-auto-suggest-ul" type="search" name="q" role="combobox" placeholder="Search Xbox.com" data-m='{"cN":"SearchBox_nav","id":"n1c3c1c9c2m1r1a1","sN":1,"aN":"c3c1c9c2m1r1a1"}' data-toggle="tooltip" data-placement="right" title="Search Xbox.com" />
                                    <button id="search" aria-label="Search Xbox.com" class="c-glyph" data-m='{"cN":"Search_nav","id":"n2c3c1c9c2m1r1a1","sN":2,"aN":"c3c1c9c2m1r1a1"}' data-bi-mto="true" aria-expanded="false">
                                        <span role="presentation">Search</span>
                                        <span role="tooltip" class="c-uhf-tooltip c-uhf-search-tooltip">Search Xbox.com</span>
                                    </button>
                                <div class="m-auto-suggest" id="universal-header-search-auto-suggest-transparent" role="group">
                                    <ul class="c-menu" id="universal-header-search-auto-suggest-ul" aria-label="Search Suggestions" aria-hidden="true" data-bi-dnt="true" data-bi-mto="true" data-js-auto-suggest-position="default" role="listbox" data-tel="jsll" data-m='{"cN":"search suggestions_cont","cT":"Container","id":"c3c3c1c9c2m1r1a1","sN":3,"aN":"c3c1c9c2m1r1a1"}'></ul>
                                </div>
                                
                            </form>
                        <button data-m='{"cN":"cancel-search","pid":"Cancel Search","id":"nn4c1c9c2m1r1a1","sN":4,"aN":"c1c9c2m1r1a1"}' id="cancel-search" class="cancel-search" aria-label="Cancel Search">
                            <span>Cancel</span>
                        </button>
                    <a id="uhf-shopping-cart"
                       aria-label="0 items in shopping cart"
                       class="c-action-trigger c-glyph c-uhf-nav-link glyph-shopping-cart"
                       href="https://www.microsoft.com/en-us/store/buy"
                       data-src-dmn-chk="true"
                       data-m='{"cN":"GlobalNav_Cart_nav","bhvr":82,"id":"n5c1c9c2m1r1a1","sN":5,"aN":"c1c9c2m1r1a1"}'>
                        <span class="shopping-cart-amount x-hidden" aria-hidden="true">0</span>
                        <span class="c-cart-lbl c-st-lbl">Cart</span>
                        <span id="uhf-shopping-cart-tooltip" class="c-uhf-tooltip" role="tooltip">0 items in shopping cart</span>
                    </a>
                            <iframe id="shell-cart-count" data-src="//www.microsoft.com/store/buy/cartcount"></iframe>
                        <div id="meControl" class="c-me"  data-signinsettings='{"containerId":"meControl","enabled":true,"headerHeight":48,"debug":false,"extensibleLinks":[{"string":"Xbox profile","url":"https://account.xbox.com/Profile?xr=mebarnav","id":""},{"string":"Xbox settings","url":"https://account.xbox.com/Settings/Home/?xr=mebarnav#","id":""},{"string":"Subscriptions","url":"https://account.microsoft.com/services?ref=xboxme","id":""},{"string":"Redeem code","url":"https://redeem.microsoft.com/enter?ref=xboxcom","id":""}],"userData":{"idp":"msa","firstName":"","lastName":"","memberName":"","cid":"","authenticatedState":"3"},"rpData":{"preferredIdp":"msa","msaInfo":{"signInUrl":"https://account.xbox.com/Account/Signin","signOutUrl":"","meUrl":"https://login.live.com/me.srf?wa=wsignin1.0"},"aadInfo":{"signOutUrl":"","appId":"","siteUrl":"","blockMsaFed":true}}}' data-m='{"cN":"GlobalNav_Account_cont","cT":"Container","id":"c6c1c9c2m1r1a1","sN":6,"aN":"c1c9c2m1r1a1"}'>
                            <div class="msame_Header">
                                <div class="msame_Header_name st_msame_placeholder">Sign in</div>
                            </div>
                            
                        </div>
                
            </div>
        </div>
        
        
    </div>
    
</header>




    </div>
        </div>

    </div>



<script>
    (function () {
        var checkSearchSubmit = function (e) {
            if (searchInputValue.value.trim() === "") {
                e.preventDefault();
                return;
            }
        };
        var searchInputValue = document.getElementById('cli_shellHeaderSearchInput');
        if (searchInputValue && searchInputValue.form.id === "searchForm") {
            document.getElementById("searchForm").addEventListener("submit", checkSearchSubmit, false);
        }
    })();
</script>


<script type="text/javascript">

    require(['jquery', 'xbox.common'],
        function ($, common)
        {
            var accountAuthority = "https://account.xbox.com/";
            var signInUrl = "https://account.xbox.com/Account/Signin?returnUrl=https%3a%2f%2fwww.xbox.com%3a443%2fError%3f404%253bhttps%253a%252f%252fwww.xbox.com%253a443%252fen-US%252findex.js";
            var signOutUrl = "https://account.xbox.com/Account/Signout?returnUrl=https%3a%2f%2fwww.xbox.com%3a443%2fError%3f404%253bhttps%253a%252f%252fwww.xbox.com%253a443%252fen-US%252findex.js";
            var locale = common.locale();
            var userDataMeControlPath = common.formatString('{0}{1}/Profile/UserDataMeControl', accountAuthority, locale);

            var containerControl="header";
            var controlName="MeControl";
            var buttonClickEvent = "4";

            var shellOptions = {
                meControlOptions: {
                    rpData: {
                        msaInfo: {
                            signInUrl: signInUrl,
                            signOutUrl: signOutUrl,
                            accountSettingsUrl: accountAuthority
                        },
                        preferredIdp: "msa"
                    },
                    userData: {
                        idp: "msa",
                        firstName: "",
                        lastName: "",
                        memberName: "",
                        cid: "",
                        authenticatedState: "3"
                    }
                }
            };

            if (window.msCommonShell) {
                loadShell();
            }
            else {
                window.onShellReadyToLoad = function () {
                    window.onShellReadyToLoad = null;
                    loadShell();
                }
            }

            // all browsers except IE before version 9
            if (window.addEventListener) {
                window.addEventListener("message", receiveMessage, false);
            }
            else {
                if (window.attachEvent) {
                    window.attachEvent("onmessage", receiveMessage);
                }
            }

            function loadShellWithUserData(data) {
                shellOptions.meControlOptions.userData.firstName = data.FirstName;
                shellOptions.meControlOptions.userData.lastName = data.LastName;
                shellOptions.meControlOptions.userData.nickName = data.GamerTag;
                shellOptions.meControlOptions.userData.tileUrl = data.PublicGamerPic;
                shellOptions.meControlOptions.userData.memberName = data.Email;
                shellOptions.meControlOptions.userData.cid = data.CID.toString();
                shellOptions.meControlOptions.userData.authenticatedState = "1";
                shellOptions.meControlOptions.userData.accountTier = data.AccountTier;
                window.msCommonShell.load(shellOptions);
                if (currentUser) {
                    currentUser.tier = shellOptions.meControlOptions.userData.accountTier;
                    currentUser.isSignedIn = true;
                }
            }

            function loadShell() {
                if (window.msCommonShell) {
                          window.msCommonShell.load(shellOptions);
                }
            }

            function receiveMessage(event) {
                if (event.origin + "/" == accountAuthority && event.data.FirstName) {
                    loadShellWithUserData(event.data);
                }
                else {
                    return;
                }

            }
        });
</script>



        <div id="BodyContent" class="container" tabindex="-1" role="main">
            






<br class="clear"/>
<div>
        <div id="TopContentBlockList_1" class="">
            
           
               <head>
<meta name="viewport" content="width=device-width, initial-scale=1">
 <link rel="stylesheet" href="https://mwf-service.akamaized.net/mwf/css/bundle/1.57.8/west-european/green/mwf-main.min.css">
 <link rel="stylesheet" href="/en-US/global-resources/templates/MWF/CSS/xbox-MWF.css">

<script>
$('link[rel=stylesheet][href*="/bundles/xboxsplash"]').remove();
$('link[rel=stylesheet][href*="/bundles/xboxstyles"]').remove();
$('link[rel=stylesheet][href*="/bundles/xboxonemobile"]').remove();
$('link[rel=stylesheet][href*="/bundles/xboxonecommon"]').remove();
$('link[rel=stylesheet][href*="/bundles/xboxonemobile"]').remove();
$('link[rel=stylesheet][href*="/Shell/css/contentBlocks.mobile.css"]').remove();

$('link[rel=stylesheet][href~="/en-us/global-resources/Picchu-Grid/CSS/mscom-grid-mixed.css"]').remove();
$('link[rel=stylesheet][href~="/en-us/global-resources/Picchu-Grid/CSS/Picchu.css"]').remove();
</script>
</head>
<!--<div id="btt"></div>-->

<div class="high-contrast-test" style="color:#999; width:0px; height: 0px;"></div>
<script>
    if ($('.high-contrast-test').css('color') == 'rgb(255, 255, 255)' ||  ($('.high-contrast-test').css('color').toLowerCase() == '#fff')){
       $('html').addClass('high-contrast-mode white-on-black');
    }

    if ($('.high-contrast-test').css('color') == 'rgb(0, 0, 0)' ||  ($('.high-contrast-test').css('color') == '#000')){
       $('html').addClass('high-contrast-mode black-on-white');
    }
</script>

               
               
                 
            </div>
                <br class="clear" />
                <br class="clear"/>
        <div id="TopContentBlockList_2" class="contentarea1">
            
           
               <div class="m-hero-item f-medium f-x-right f-y-center context-accessory theme-dark random1 zmt" itemscope itemtype="http://schema.org/Product">
    <picture>
        <source srcset="https://compass-ssl.xbox.com/assets/80/96/8096d045-2384-4b43-9b73-6d5f282149cc.jpg?n=404_Page-Hero-1084_Minecraft-Dungeons_1920x720.jpg" media="(min-width: 1084px)">
        <source srcset="https://compass-ssl.xbox.com/assets/e7/97/e797eb13-e2d8-4e46-ac2d-0a1287a2abc9.jpg?n=404_Page-Hero-768_Minecraft-Dungeons_1083x609.jpg" media="(min-width: 768px)">
        <source srcset="https://compass-ssl.xbox.com/assets/4a/3f/4a3f3def-068c-4ab2-9cad-72c446b4fd6f.jpg?n=404_Page-Hero-0_Minecraft-Dungeons_767x431.jpg" media="(min-width:0)">
        <img srcset="https://compass-ssl.xbox.com/assets/4a/3f/4a3f3def-068c-4ab2-9cad-72c446b4fd6f.jpg?n=404_Page-Hero-0_Minecraft-Dungeons_767x431.jpg" src="https://compass-ssl.xbox.com/assets/4a/3f/4a3f3def-068c-4ab2-9cad-72c446b4fd6f.jpg?n=404_Page-Hero-0_Minecraft-Dungeons_767x431.jpg" alt="Minecraft Dungeons page not found" title="404 hero image" >
    </picture>
    <div>
        <div>
            <h1 class="c-heading">Let your torch guide you down another path.</h1>
            <p class="c-subheading">Page not found.</p>
        </div>
    </div>
</div>

<div class="m-hero-item f-medium f-x-left f-y-center context-accessory theme-dark random2 zmt" itemscope itemtype="http://schema.org/Product">
    <picture>
        <source srcset="https://compass-ssl.xbox.com/assets/36/bc/36bcf309-fd0d-4a87-83fc-bf3342aa12a6.jpg?n=404_Page-Hero-1084_Grounded_1920x720.jpg" media="(min-width: 1084px)">
        <source srcset="https://compass-ssl.xbox.com/assets/c5/61/c561253d-69d8-4366-a378-057ac70d1ccc.jpg?n=404_Page-Hero-768_Grounded_1083x609.jpg" media="(min-width: 768px)">
        <source srcset="https://compass-ssl.xbox.com/assets/17/9f/179f705d-8201-4d00-a105-854fa7ce486d.jpg?n=404_Page-Hero-0_Grounded_767x431.jpg" media="(min-width:0)">
        <img srcset="https://compass-ssl.xbox.com/assets/17/9f/179f705d-8201-4d00-a105-854fa7ce486d.jpg?n=404_Page-Hero-0_Grounded_767x431.jpg" src="https://compass-ssl.xbox.com/assets/17/9f/179f705d-8201-4d00-a105-854fa7ce486d.jpg?n=404_Page-Hero-0_Grounded_767x431.jpg" alt="Grounded page not found" title="404 hero image">
    </picture>
    <div>
        <div>
            <h1 class="c-heading">You’re headed for the wrong backyard!</h1>
            <p class="c-subheading">Page not found.</p>
        </div>
    </div>
</div>

<div class="m-hero-item f-medium f-x-right f-y-center context-accessory theme-dark random3 zmt" itemscope itemtype="http://schema.org/Product">
    <picture>
        <source srcset="https://compass-ssl.xbox.com/assets/1e/4f/1e4f80cf-3ebf-45ed-890a-5fb6077abd31.jpg?n=404_Page-Hero-1084_Wasteland-3_1920x720.jpg" media="(min-width: 1084px)">
        <source srcset="https://compass-ssl.xbox.com/assets/c7/96/c79619e4-930d-4395-a90a-73532b7ead78.jpg?n=404_Page-Hero-768_Wasteland-3_1083x609.jpg" media="(min-width: 768px)">
        <source srcset="https://compass-ssl.xbox.com/assets/5e/9d/5e9d9ab5-a5cb-416d-afa8-cf48b68cc9cf.jpg?n=404_Page-Hero-0_Wasteland-3_767x431.jpg" media="(min-width:0)">
        <img srcset="https://compass-ssl.xbox.com/assets/5e/9d/5e9d9ab5-a5cb-416d-afa8-cf48b68cc9cf.jpg?n=404_Page-Hero-0_Wasteland-3_767x431.jpg" src="https://compass-ssl.xbox.com/assets/5e/9d/5e9d9ab5-a5cb-416d-afa8-cf48b68cc9cf.jpg?n=404_Page-Hero-0_Wasteland-3_767x431.jpg" alt="Wasteland 3 page not found" title="404 hero image">
    </picture>
    <div>
        <div>
            <h1 class="c-heading">This trail may be a little too cold.</h1>
            <p class="c-subheading">Page not found.</p>
        </div>
    </div>
</div>

<div class="m-hero-item f-medium f-x-left f-y-center context-accessory theme-dark random4 zmt" itemscope itemtype="http://schema.org/Product">
    <picture>
        <source srcset="https://compass-ssl.xbox.com/assets/ef/e2/efe2f71a-810e-4d70-9c90-94c2b0a19c4b.jpg?n=404_Page-Hero-1084_SoT_1920x720.jpg" media="(min-width: 1084px)">
        <source srcset="https://compass-ssl.xbox.com/assets/79/fa/79fa7145-3b45-4979-a973-9ab7164eaae9.jpg?n=404_Page-Hero-768_SoT_1083x609.jpg" media="(min-width: 768px)">
        <source srcset="https://compass-ssl.xbox.com/assets/40/79/4079f8a8-4495-4bd3-965f-84e7eacb3588.jpg?n=404_Page-Hero-0_SoT_767x431.jpg" media="(min-width:0)">
        <img srcset="https://compass-ssl.xbox.com/assets/40/79/4079f8a8-4495-4bd3-965f-84e7eacb3588.jpg?n=404_Page-Hero-0_SoT_767x431.jpg" src="https://compass-ssl.xbox.com/assets/40/79/4079f8a8-4495-4bd3-965f-84e7eacb3588.jpg?n=404_Page-Hero-0_SoT_767x431.jpg" alt="Sea of Thieves page not found" title="404 hero image">
    </picture>
    <div>
        <div>
            <h1 class="c-heading">Double check your map, Captain.</h1>
            <p class="c-subheading">Page not found.</p>
        </div>
    </div>
</div>

<div class="m-hero-item f-medium f-x-left f-y-center context-accessory theme-dark random5 zmt" itemscope itemtype="http://schema.org/Product">
    <picture>
        <source srcset="https://compass-ssl.xbox.com/assets/87/8c/878ca7fe-2a08-4ec7-a8bf-68f3bfce1126.jpg?n=404_Page-Hero-1084_Ori-tWotW_1920x720.jpg" media="(min-width: 1084px)">
        <source srcset="https://compass-ssl.xbox.com/assets/5a/fd/5afde38f-c920-42f6-96cf-52fb9a521767.jpg?n=404_Page-Hero-768_Ori-tWotW_1083x609.jpg" media="(min-width: 768px)">
        <source srcset="https://compass-ssl.xbox.com/assets/95/40/954008b3-2b7b-4aeb-894d-ce631c8753b5.jpg?n=404_Page-Hero-0_Ori-tWotW_767x431.jpg" media="(min-width:0)">
        <img srcset="https://compass-ssl.xbox.com/assets/95/40/954008b3-2b7b-4aeb-894d-ce631c8753b5.jpg?n=404_Page-Hero-0_Ori-tWotW_767x431.jpg" src="https://compass-ssl.xbox.com/assets/95/40/954008b3-2b7b-4aeb-894d-ce631c8753b5.jpg?n=404_Page-Hero-0_Ori-tWotW_767x431.jpg" alt="Ori & The Will of the Wisps page not found" title="404 hero image">
    </picture>
    <div>
        <div>
            <h1 class="c-heading">Destiny lies another way.</h1>
            <p class="c-subheading">Page not found.</p>
        </div>
    </div>
</div>


               
               
                 
            </div>
                <br class="clear" />

</div>

<div class="GDPHero">
    



</div>


<br class="clear"/>
<div>
        <div id="ContentBlockList_1" class="">
            
           
               <div class="" data-grid="container"></div>
<div class="" data-grid="container">
<h2 class="x-screen-reader">Games, Consoles and Support</h2>
    <div data-grid="col-12 stack-2">
        <div data-grid="col-4 pad-12x">
            <div data-grid="col-12">
                <section class="m-content-placement-item f-size-medium">
                        <picture>
                            <source srcset="https://compass-ssl.xbox.com/assets/5b/6b/5b6b856d-efab-4d3b-8729-c593618fbc41.jpg?n=404_Content-Placement-0_Games_788x444.jpg" media="(min-width:0)">
                            <img src="https://compass-ssl.xbox.com/assets/5b/6b/5b6b856d-efab-4d3b-8729-c593618fbc41.jpg?n=404_Content-Placement-0_Games_788x444.jpg" alt="An array of xbox games including Assassin's Creed Valhalla, Fifa 21, and Cyberpunk 2077">
                        </picture>
                        <h3 class="c-heading">Xbox games</h3>
                        <p class="c-paragraph">Browse Xbox games to find the latest hot new releases, blockbuster exclusives, Indie games and more.</p>
            <div class="c-group">
                <a href="https://www.xbox.com/games/all-games" class="c-call-to-action c-glyph" data-cta="learn" aria-label="Explore all xbox games">
                    <span>EXPLORE GAMES</span>
                </a>
            </div>
                </section>
            </div>
        </div>

        <div data-grid="col-4 pad-12x">
            <div data-grid="col-12">
                <section class="m-content-placement-item f-size-medium">
                        <picture>
                            <source srcset="https://compass-ssl.xbox.com/assets/bf/fa/bffaf4d2-8ee9-49a2-9757-357ab3ca94fe.jpg?n=404_Content-Placement-0_Consoles_788x444.jpg" media="(min-width:0)">
                            <img src="https://compass-ssl.xbox.com/assets/bf/fa/bffaf4d2-8ee9-49a2-9757-357ab3ca94fe.jpg?n=404_Content-Placement-0_Consoles_788x444.jpg" alt="Xbox series X and Xbox series S consoles">
                        </picture>
                        <h3 class="c-heading">Xbox consoles</h3>
                        <p class="c-paragraph">Choose the Xbox that is right for you.</p>
            <div class="c-group">
                <a href="https://www.xbox.com/consoles/all-consoles" class="c-call-to-action c-glyph" data-cta="learn" aria-label="Explore xbox consoles">
                    <span>EXPLORE CONSOLES</span>
                </a>
            </div>
                </section>
            </div>
        </div>

        <div data-grid="col-4 pad-12x">
            <div data-grid="col-12">
                <section class="m-content-placement-item f-size-medium">
                        <picture>
                            <source srcset="https://compass-ssl.xbox.com/assets/d8/08/d808fdc6-eb5e-40e7-b1da-18c469c3fe74.svg?n=404_Content-Placement-0_Support_788x444.svg" media="(min-width:0)">
                            <img src="https://compass-ssl.xbox.com/assets/d8/08/d808fdc6-eb5e-40e7-b1da-18c469c3fe74.svg?n=404_Content-Placement-0_Support_788x444.svg" alt="Support icon: a question mark inside a circle">
                        </picture>
                        <h3 class="c-heading">Xbox Support</h3>
                        <p class="c-paragraph">Have questions you can’t find the answer to? Get the help you need.</p>

            <div class="c-group">
                <a href="https://support.xbox.com/" class="c-call-to-action c-glyph" aria-label="Get help from Xbox support" data-cta="internal">
                    <span>GET HELP</span>
                </a>
            </div>
                </section>
            </div>
        </div>
    </div>


</div>
<div class="m-feature"></div>

               
               
                 
            </div>
                <br class="clear" />
                <br class="clear"/>
        <div id="ContentBlockList_2" class="">
            
           
               <script>
$(document).ready(function(){
 function pickrandom(arr) {
  var arrlength = arr.length;
  var randomnum = Math.floor(Math.random() * arrlength);
  var arrvalue = arr[randomnum];
  return arrvalue;
 };

(function() {
  var array = ["random1", "random2", "random3", "random4", "random5"]
  var showdiv = pickrandom(array);

  $(".contentarea1 ." + showdiv).addClass("showrandom")
 })();

 (function() {
  var array = ["random1", "random2", "random3"]
  var showdiv = pickrandom(array);
  $(".contentarea2 ." + showdiv).addClass("showrandom")
 })();
});
</script>

               
               
                 
            </div>
                <br class="clear" />
                <br class="clear"/>
        <div id="ContentBlockList_3" class="">
            
           
               
<script async="async" src="https://mwf-service.akamaized.net/mwf/js/bundle/1.57.8/mwf-auto-init-main.var.min.js"></script>
            <noscript></noscript>
<!--<a href="#btt" class="m-back-to-top smoothscroll" aria-disabled="true" tabindex="0">
    <div class="c-glyph glyph-up" aria-label="Back to top"></div>
</a>-->

<script>
//hreflang 
$("link[hreflang]").remove();
var urlRegion = document.URL.toLowerCase().split("xbox.com/")[1].slice(0, 5);
var allregions = ["en-us", "en-au", "en-hk", "en-in", "en-nz", "en-sg", "ja-jp", "ko-kr", "zh-hk", "zh-tw", "ar-ae", "ar-sa", "cs-cz", "da-dk", "de-at", "de-ch", "de-de", "el-gr", "en-gb", "en-ie", "en-za", "fi-fi", "fr-be", "fr-ch", "fr-fr", "he-il", "hu-hu", "it-it", "nb-no", "nl-be", "nl-nl", "pl-pl", "pt-pt", "ru-ru", "sk-sk", "sv-se", "tr-tr", "en-ca", "fr-ca", "es-ar", "es-cl", "es-co", "es-es", "es-mx", "pt-br"];
var hlurl = $("meta[property='og:url']").attr("content")
if (hlurl === undefined) {
  hlurl = "https://www.xbox.com/" + urlRegion;
} else {
  hlurl = hlurl.toLowerCase();
}

// Aria Tool
var currentUrl = document.URL.toLowerCase();
if ((currentUrl.indexOf("preview") !== -1) && (currentUrl.indexOf("?aria-tool") !== -1)) {
    $("body").append('<script type="text/javascript" src="/en-US/global-resources/script/js/aria-alt.js"></s' + 'cript>');
}

for (var i = 0; i < allregions.length; i++) {
  var regionpre = allregions[i].split("-")[0];
  var regionpost = allregions[i].split("-")[1].toUpperCase();
  var regionfull = regionpre + "-" + regionpost
  var hllink = hlurl.replace(urlRegion, regionfull);
  $("head").prepend('<link rel="alternate" href="' + hllink + '" hreflang="' + regionfull + '" />');
}
</script>
<!-- Full Path in order to publish -->
<script type="text/javascript" src="https://www.xbox.com/en-US/global-resources/templates/MWF/JS/xbox-MWF.js"></script>
   

               
               
                 
            </div>
                <br class="clear" />

</div>


        </div>

        
        
                    <img src="https://account.xbox.com/en-US/featureSync.gif" style="display:none" />
                <img src="https://c.xbox.com/c.gif" style="display:none" />
                <div id="BodyFooter" class="container">
                        <div id="footerArea" class="uhf"  data-m='{"cN":"footerArea","cT":"Area_coreuiArea","id":"a2Body","sN":2,"aN":"Body"}'>
                <div id="footerRegion"      data-region-key="footerregion" data-m='{"cN":"footerRegion","cT":"Region_coreui-region","id":"r1a2","sN":1,"aN":"a2"}' >

    <div  id="footerUniversalFooter" data-m='{"cN":"footerUniversalFooter","cT":"Module_coreui-universalfooter","id":"m1r1a2","sN":1,"aN":"r1a2"}'  data-module-id="Category|footerRegion|coreui-region|footerUniversalFooter|coreui-universalfooter">
        



<footer id="uhf-footer" class="c-uhff context-uhf"  data-uhf-mscc-rq="false" data-footer-footprint="/XboxcomUHF/FullFooter, fromService: True" data-m='{"cN":"Uhf footer_cont","cT":"Container","id":"c1m1r1a2","sN":1,"aN":"m1r1a2"}'>
        <nav class="c-uhff-nav" aria-label="Footer Resource links" data-m='{"cN":"Footer nav_cont","cT":"Container","id":"c1c1m1r1a2","sN":1,"aN":"c1m1r1a2"}'>
            
                <div class="c-uhff-nav-row">
                    <div class="c-uhff-nav-group" data-m='{"cN":"footerNavColumn1_cont","cT":"Container","id":"c1c1c1m1r1a2","sN":1,"aN":"c1c1m1r1a2"}'>
                        <div class="c-heading-4" role="heading" aria-level="2">Browse</div>
                        <ul class="c-list f-bare">
                            <li>
                                <a aria-label="Xbox consoles Browse" class="c-uhff-link" href="https://www.xbox.com/en-US/consoles?xr=footnav" data-m='{"cN":"Xbox consoles_nav","id":"n1c1c1c1m1r1a2","sN":1,"aN":"c1c1c1m1r1a2"}'>Xbox consoles</a>
                            </li>
                            <li>
                                <a aria-label="Xbox games Browse" class="c-uhff-link" href="https://www.xbox.com/en-US/games?xr=footnav" data-m='{"cN":"Xbox games_nav","id":"n2c1c1c1m1r1a2","sN":2,"aN":"c1c1c1m1r1a2"}'>Xbox games</a>
                            </li>
                            <li>
                                <a aria-label="Xbox Game Pass Browse" class="c-uhff-link" href="https://www.xbox.com/en-US/xbox-game-pass?xr=footnav" data-m='{"cN":"Xbox Game Pass_nav","id":"n3c1c1c1m1r1a2","sN":3,"aN":"c1c1c1m1r1a2"}'>Xbox Game Pass</a>
                            </li>
                            <li>
                                <a aria-label="Xbox accessories Browse" class="c-uhff-link" href="https://www.xbox.com/en-US/accessories?xr=footnav" data-m='{"cN":"Xbox accessories_nav","id":"n4c1c1c1m1r1a2","sN":4,"aN":"c1c1c1m1r1a2"}'>Xbox accessories</a>
                            </li>

                        </ul>
                        
                    </div>
                    <div class="c-uhff-nav-group" data-m='{"cN":"footerNavColumn2_cont","cT":"Container","id":"c2c1c1m1r1a2","sN":2,"aN":"c1c1m1r1a2"}'>
                        <div class="c-heading-4" role="heading" aria-level="2">Resources</div>
                        <ul class="c-list f-bare">
                            <li>
                                <a aria-label="Xbox News Resources" class="c-uhff-link" href="https://news.xbox.com?xr=footnav" data-m='{"cN":"Xbox News_nav","id":"n1c2c1c1m1r1a2","sN":1,"aN":"c2c1c1m1r1a2"}'>Xbox News</a>
                            </li>
                            <li>
                                <a aria-label="Xbox Support Resources" class="c-uhff-link" href="https://support.xbox.com?xr=footnav" data-m='{"cN":"Xbox Support_nav","id":"n2c2c1c1m1r1a2","sN":2,"aN":"c2c1c1m1r1a2"}'>Xbox Support</a>
                            </li>
                            <li>
                                <a aria-label="Feedback Resources" class="c-uhff-link" href="https://aka.ms/xboxideas?xr=footnav" data-m='{"cN":"Feedback_nav","id":"n3c2c1c1m1r1a2","sN":3,"aN":"c2c1c1m1r1a2"}'>Feedback</a>
                            </li>
                            <li>
                                <a aria-label="Community Standards Resources" class="c-uhff-link" href="https://www.xbox.com/en-US/legal/community-standards?xr=footnav" data-m='{"cN":"Community Standards_nav","id":"n4c2c1c1m1r1a2","sN":4,"aN":"c2c1c1m1r1a2"}'>Community Standards</a>
                            </li>
                            <li>
                                <a aria-label="Photosensitive Seizure Warning Resources" class="c-uhff-link" href="https://support.xbox.com/help/family-online-safety/online-safety/photosensitive-seizure-warning?xr=footnav" data-m='{"cN":"Photosensitive Seizure Warning_nav","id":"n5c2c1c1m1r1a2","sN":5,"aN":"c2c1c1m1r1a2"}'>Photosensitive Seizure Warning</a>
                            </li>

                        </ul>
                        
                    </div>
                    <div class="c-uhff-nav-group" data-m='{"cN":"footerNavColumn3_cont","cT":"Container","id":"c3c1c1m1r1a2","sN":3,"aN":"c1c1m1r1a2"}'>
                        <div class="c-heading-4" role="heading" aria-level="2">Microsoft Store</div>
                        <ul class="c-list f-bare">
                            <li>
                                <a aria-label="Microsoft account Microsoft Store" class="c-uhff-link" href="https://account.microsoft.com?xr=footnav" data-m='{"cN":"Microsoft account_nav","id":"n1c3c1c1m1r1a2","sN":1,"aN":"c3c1c1m1r1a2"}'>Microsoft account</a>
                            </li>
                            <li>
                                <a aria-label="Microsoft Store Support Microsoft Store" class="c-uhff-link" href="https://support.microsoft.com/en-US/account-billing/contact-microsoft-store-support-4f615f2a-6bbd-fd69-6695-ae213d63eef0?xr=footnav" data-m='{"cN":"Microsoft Store Support_nav","id":"n2c3c1c1m1r1a2","sN":2,"aN":"c3c1c1m1r1a2"}'>Microsoft Store Support</a>
                            </li>
                            <li>
                                <a aria-label="Returns Microsoft Store" class="c-uhff-link" href="https://support.microsoft.com/en-US/account-billing/returning-items-you-bought-from-microsoft-store-for-exchange-or-refund-81629012-aa4f-f48b-2394-8596f415072b?xr=footnav" data-m='{"cN":"Returns_nav","id":"n3c3c1c1m1r1a2","sN":3,"aN":"c3c1c1m1r1a2"}'>Returns</a>
                            </li>
                            <li>
                                <a aria-label="Orders tracking Microsoft Store" class="c-uhff-link" href="https://account.microsoft.com/orders?xr=footnav" data-m='{"cN":"Orders tracking_nav","id":"n4c3c1c1m1r1a2","sN":4,"aN":"c3c1c1m1r1a2"}'>Orders tracking</a>
                            </li>
                            <li>
                                <a aria-label="Store locations Microsoft Store" class="c-uhff-link" href="https://www.microsoft.com/en-us/store/locations/find-a-store?icid=en-us_UF_FAS?xr=footnav" data-m='{"cN":"Store locations_nav","id":"n5c3c1c1m1r1a2","sN":5,"aN":"c3c1c1m1r1a2"}'>Store locations</a>
                            </li>

                        </ul>
                        
                    </div>
                </div>
                <div class="c-uhff-nav-row">
                    <div class="c-uhff-nav-group" data-m='{"cN":"footerNavColumn4_cont","cT":"Container","id":"c4c1c1m1r1a2","sN":4,"aN":"c1c1m1r1a2"}'>
                        <div class="c-heading-4" role="heading" aria-level="2">For Developers</div>
                        <ul class="c-list f-bare">
                            <li>
                                <a aria-label="Games For Developers" class="c-uhff-link" href="https://www.xbox.com/en-US/developers?xr=footnav" data-m='{"cN":"Games_nav","id":"n1c4c1c1m1r1a2","sN":1,"aN":"c4c1c1m1r1a2"}'>Games</a>
                            </li>
                            <li>
                                <a aria-label="ID@Xbox For Developers" class="c-uhff-link" href="https://www.xbox.com/en-US/developers/id?xr=footnav" data-m='{"cN":"ID@Xbox_nav","id":"n2c4c1c1m1r1a2","sN":2,"aN":"c4c1c1m1r1a2"}'>ID@Xbox</a>
                            </li>
                            <li>
                                <a aria-label="Windows For Developers" class="c-uhff-link" href="https://dev.windows.com/games?xr=footnav" data-m='{"cN":"Windows_nav","id":"n3c4c1c1m1r1a2","sN":3,"aN":"c4c1c1m1r1a2"}'>Windows</a>
                            </li>
                            <li>
                                <a aria-label="Creators Program For Developers" class="c-uhff-link" href="https://www.xbox.com/en-US/developers/creators-program?xr=footnav" data-m='{"cN":"Creators Program_nav","id":"n4c4c1c1m1r1a2","sN":4,"aN":"c4c1c1m1r1a2"}'>Creators Program</a>
                            </li>
                            <li>
                                <a aria-label="Designed for Xbox For Developers" class="c-uhff-link" href="https://www.xbox.com/en-US/designed-for-xbox?xr=footnav" data-m='{"cN":"Designed for Xbox_nav","id":"n5c4c1c1m1r1a2","sN":5,"aN":"c4c1c1m1r1a2"}'>Designed for Xbox</a>
                            </li>

                        </ul>
                        
                    </div>
                </div>
        </nav>
    <div class="c-uhff-base">
                <a id="locale-picker-link" aria-label="Content Language Selector. Currently set to English (United States)" class="c-uhff-link c-uhff-lang-selector c-glyph glyph-world" href="/Shell/ChangeLocale" data-m='{"cN":"locale_picker(US)_nav","id":"n5c1c1m1r1a2","sN":5,"aN":"c1c1m1r1a2"}'>English (United States)</a>

        <nav aria-label="Microsoft corporate links">
            <ul class="c-list f-bare" data-m='{"cN":"Corp links_cont","cT":"Container","id":"c6c1c1m1r1a2","sN":6,"aN":"c1c1m1r1a2"}'>
                                <li  id="c-uhff-footer_sitemap">
                    <a class="c-uhff-link" href="https://www.microsoft.com/en-us/sitemap1.aspx" data-mscc-ic="false" data-m='{"cN":"Footer_Sitemap_nav","id":"n1c6c1c1m1r1a2","sN":1,"aN":"c6c1c1m1r1a2"}'>Sitemap</a>
                </li>
                <li  id="c-uhff-footer_contactus">
                    <a class="c-uhff-link" href="https://support.microsoft.com/en-us/contactus" data-mscc-ic="false" data-m='{"cN":"Footer_ContactUs_nav","id":"n2c6c1c1m1r1a2","sN":2,"aN":"c6c1c1m1r1a2"}'>Contact Microsoft</a>
                </li>
                <li  id="c-uhff-footer_privacyandcookies">
                    <a class="c-uhff-link" href="https://go.microsoft.com/fwlink/?LinkId=521839" data-mscc-ic="false" data-m='{"cN":"Footer_PrivacyandCookies_nav","id":"n3c6c1c1m1r1a2","sN":3,"aN":"c6c1c1m1r1a2"}'>Privacy </a>
                </li>
                <li class=" x-hidden" id="c-uhff-footer_managecookies">
                    <a class="c-uhff-link" href="#" data-mscc-ic="false" data-m='{"cN":"Footer_ManageCookies_nav","id":"n4c6c1c1m1r1a2","sN":4,"aN":"c6c1c1m1r1a2"}'>Manage cookies</a>
                </li>
                <li  id="c-uhff-footer_termsofuse">
                    <a class="c-uhff-link" href="https://go.microsoft.com/fwlink/?LinkID=206977" data-mscc-ic="false" data-m='{"cN":"Footer_TermsOfUse_nav","id":"n5c6c1c1m1r1a2","sN":5,"aN":"c6c1c1m1r1a2"}'>Terms of use</a>
                </li>
                <li  id="c-uhff-footer_trademarks">
                    <a class="c-uhff-link" href="https://www.microsoft.com/trademarks" data-mscc-ic="false" data-m='{"cN":"Footer_Trademarks_nav","id":"n6c6c1c1m1r1a2","sN":6,"aN":"c6c1c1m1r1a2"}'>Trademarks</a>
                </li>
                <li  id="c-uhff-third_party_notices">
                    <a class="c-uhff-link" href="https://www.xbox.com/en-US/legal/legal-notices" data-mscc-ic="false" data-m='{"cN":"Third_Party_Notices_nav","id":"n7c6c1c1m1r1a2","sN":7,"aN":"c6c1c1m1r1a2"}'>Third Party Notices</a>
                </li>
                <li  id="c-uhff-footer_safetyandeco">
                    <a class="c-uhff-link" href="https://www.microsoft.com/en-us/devices/safety-and-eco " data-mscc-ic="false" data-m='{"cN":"Footer_SafetyAndEco_nav","id":"n8c6c1c1m1r1a2","sN":8,"aN":"c6c1c1m1r1a2"}'>Safety &amp; eco</a>
                </li>
                <li  id="c-uhff-footer_aboutourads">
                    <a class="c-uhff-link" href="https://choice.microsoft.com" data-mscc-ic="false" data-m='{"cN":"Footer_AboutourAds_nav","id":"n9c6c1c1m1r1a2","sN":9,"aN":"c6c1c1m1r1a2"}'>About our ads</a>
                </li>

                <li>&#169; Microsoft 2022</li>
                
            </ul>
        </nav>
    </div>
    
</footer>




    </div>
        </div>

    </div>

                </div>

    </div>
</html>
